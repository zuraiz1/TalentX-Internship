#!/usr/bin/env python3
"""
filter_trainer.py
------------------
Part 1 of 2 (News Watch project): the training program.

Pulls articles from RSS feeds (feeds.json), serves a "swipe" web UI to
label them relevant / not relevant, logs every label to data/training_data.jsonl,
and (on request) trains a simple bag-of-words logistic regression model on
everything labeled so far, exporting the result as human-readable keyword
weights to data/filter_weights.json.

That weights file is the *only* thing news_watch.py depends on -- it's plain
JSON, no sklearn required to read it.

Run:
    python3 filter_trainer.py
Then open http://127.0.0.1:5050
"""

import calendar
import hashlib
import json
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import feedparser
from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

FEEDS_FILE = BASE_DIR / "feeds.json"
TRAINING_LOG = DATA_DIR / "training_data.jsonl"
WEIGHTS_FILE = DATA_DIR / "filter_weights.json"

MIN_SAMPLES_TO_TRAIN = 20  # below this, results are too noisy to be useful

app = Flask(__name__, static_folder="static", static_url_path="")

# ---------------------------------------------------------------------------
# In-memory article pool
# ---------------------------------------------------------------------------
_pool_lock = threading.Lock()
_pool = []  # list of article dicts, newest fetch first
_pool_fetched_at = 0
POOL_TTL_SECONDS = 15 * 60  # re-fetch feeds at most every 15 minutes

_log_lock = threading.Lock()  # guards reads/writes of TRAINING_LOG


def url_hash(url: str) -> str:
    return hashlib.sha256(url.strip().encode("utf-8")).hexdigest()


def load_feeds():
    with open(FEEDS_FILE, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    return cfg.get("feeds", [])


def already_labeled_hashes():
    hashes = set()
    if TRAINING_LOG.exists():
        with open(TRAINING_LOG, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    hashes.add(url_hash(rec["url"]))
                except Exception:
                    continue
    return hashes


def extract_image(entry):
    # Try common feedparser locations for an image, in order of reliability.
    if "media_content" in entry:
        for m in entry.media_content:
            if m.get("url"):
                return m["url"]
    if "media_thumbnail" in entry:
        for m in entry.media_thumbnail:
            if m.get("url"):
                return m["url"]
    if "links" in entry:
        for l in entry.links:
            if l.get("type", "").startswith("image"):
                return l.get("href")
    if "enclosures" in entry:
        for enc in entry.enclosures:
            if enc.get("type", "").startswith("image"):
                return enc.get("href") or enc.get("url")
    # Last resort: sniff an <img src="..."> out of the summary/content HTML
    html = entry.get("summary", "") or ""
    match = re.search(r'<img[^>]+src="([^"]+)"', html)
    if match:
        return match.group(1)
    return None


def clean_html(raw):
    if not raw:
        return ""
    text = re.sub(r"<[^>]+>", " ", raw)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_summary(entry, title):
    # Some feeds put the full article body in "content", some put an actual
    # excerpt in "summary"/"description", and some (annoyingly) just repeat
    # the title as the summary. Try each candidate in order and skip any
    # that's empty, too short, or just the title again.
    candidates = []
    if "content" in entry and entry.content:
        candidates.append(entry.content[0].get("value", ""))
    if "summary" in entry:
        candidates.append(entry.summary)
    if "description" in entry:
        candidates.append(entry.get("description", ""))

    title_norm = title.strip().lower()
    for raw in candidates:
        cleaned = clean_html(raw)
        if cleaned and cleaned.strip().lower() != title_norm and len(cleaned) > 15:
            return cleaned[:400]
    return ""


def extract_published(entry):
    # Returns a UTC unix timestamp (seconds), or None if the feed doesn't say.
    struct = entry.get("published_parsed") or entry.get("updated_parsed")
    if not struct:
        return None
    try:
        return calendar.timegm(struct)
    except Exception:
        return None


def fetch_pool(force=False):
    global _pool, _pool_fetched_at
    with _pool_lock:
        if not force and (time.time() - _pool_fetched_at) < POOL_TTL_SECONDS and _pool:
            return _pool

        feeds = load_feeds()
        labeled = already_labeled_hashes()
        seen_in_this_fetch = set()
        articles = []

        for feed_url in feeds:
            try:
                parsed = feedparser.parse(feed_url)
                source_name = parsed.feed.get("title", feed_url)
            except Exception:
                continue

            for entry in parsed.entries:
                link = entry.get("link")
                if not link:
                    continue
                h = url_hash(link)
                if h in labeled or h in seen_in_this_fetch:
                    continue
                seen_in_this_fetch.add(h)

                title = entry.get("title", "").strip()
                summary = extract_summary(entry, title)
                image = extract_image(entry)
                published_ts = extract_published(entry)

                if not title:
                    continue

                articles.append(
                    {
                        "id": h,
                        "url": link,
                        "title": title,
                        "summary": summary,
                        "image": image,
                        "source": source_name,
                        "published_ts": published_ts,
                    }
                )

        _pool = articles
        _pool_fetched_at = time.time()
        return _pool


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/next")
def api_next():
    n = int(request.args.get("n", 5))
    pool = fetch_pool()
    with _pool_lock:
        batch = pool[:n]
        _pool[:] = pool[n:]
    return jsonify({"articles": batch, "remaining_in_pool": len(_pool)})


@app.route("/api/swipe", methods=["POST"])
def api_swipe():
    data = request.get_json(force=True)
    required = {"url", "title", "label"}
    if not required.issubset(data):
        return jsonify({"error": "missing fields"}), 400

    record = {
        "url": data["url"],
        "title": data["title"],
        "summary": data.get("summary", ""),
        "source": data.get("source", ""),
        "label": int(data["label"]),  # 1 = relevant, 0 = not relevant
        "loved": bool(data.get("loved", False)),  # extra-strong positive signal
        "ts": datetime.now(timezone.utc).isoformat(),
    }
    with _log_lock:
        with open(TRAINING_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")

    return jsonify({"status": "ok"})


@app.route("/api/undo", methods=["POST"])
def api_undo():
    with _log_lock:
        if not TRAINING_LOG.exists():
            return jsonify({"error": "Nothing to undo"}), 400
        with open(TRAINING_LOG, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if not lines:
            return jsonify({"error": "Nothing to undo"}), 400
        last_line = lines.pop()
        with open(TRAINING_LOG, "w", encoding="utf-8") as f:
            f.writelines(lines)

    try:
        removed = json.loads(last_line)
    except Exception:
        removed = None

    return jsonify({"status": "ok", "removed": removed})


@app.route("/api/stats")
def api_stats():
    total, pos, neg, loved = 0, 0, 0, 0
    if TRAINING_LOG.exists():
        with open(TRAINING_LOG, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                total += 1
                if rec["label"] == 1:
                    pos += 1
                else:
                    neg += 1
                if rec.get("loved"):
                    loved += 1

    weights_meta = None
    if WEIGHTS_FILE.exists():
        with open(WEIGHTS_FILE, "r", encoding="utf-8") as f:
            w = json.load(f)
        weights_meta = {
            "trained_at": w.get("trained_at"),
            "trained_on": w.get("trained_on"),
            "vocab_size": len(w.get("weights", {})),
        }

    return jsonify(
        {
            "total_labeled": total,
            "relevant": pos,
            "not_relevant": neg,
            "loved": loved,
            "min_needed_to_train": MIN_SAMPLES_TO_TRAIN,
            "current_filter": weights_meta,
        }
    )


@app.route("/api/train", methods=["POST"])
def api_train():
    from train_filter import train_and_export  # local import: keeps sklearn out of hot path

    try:
        result = train_and_export(TRAINING_LOG, WEIGHTS_FILE, MIN_SAMPLES_TO_TRAIN)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    return jsonify(result)


if __name__ == "__main__":
    print(f"Loaded {len(load_feeds())} feed(s) from {FEEDS_FILE}")
    print("Open http://127.0.0.1:5050 to start swiping")
    app.run(host="127.0.0.1", port=5050, debug=False)
