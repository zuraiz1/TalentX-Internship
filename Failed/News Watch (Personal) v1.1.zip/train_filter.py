"""
train_filter.py
----------------
Turns data/training_data.jsonl (your swipe history) into
data/filter_weights.json (a plain word -> weight map).

This is the only file that imports scikit-learn. Everything downstream
(news_watch.py) just reads the JSON it produces and does a dot product --
no ML library needed at read time.

Design choice: we retrain from the FULL swipe log every time, rather than
incrementally updating a model. With a few hundred/thousand examples this
takes a fraction of a second, and it avoids the vocabulary-drift headaches
that come with incremental (partial_fit) training on text -- new words you
swipe on later wouldn't have existed in an old vocabulary. Simplicity and
correctness over marginal speed here.
"""

import json
from datetime import datetime, timezone

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

# How much more a "Loved it" swipe counts than a plain "Relevant" swipe when
# fitting the model. 1.0 would mean no boost; higher pulls the model harder
# toward whatever keywords show up in your loved articles. 3.0 is a
# reasonable starting point -- tune it if loved topics aren't standing out
# enough (raise it) or are dominating everything else (lower it).
LOVE_WEIGHT = 3.0


def load_training_data(path):
    titles_and_summaries = []
    labels = []
    sample_weights = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            text = f"{rec.get('title', '')} {rec.get('summary', '')}"
            titles_and_summaries.append(text)
            labels.append(int(rec["label"]))
            sample_weights.append(LOVE_WEIGHT if rec.get("loved") else 1.0)
    return titles_and_summaries, labels, sample_weights


def train_and_export(training_log_path, weights_out_path, min_samples):
    if not training_log_path.exists():
        raise ValueError("No training data yet -- swipe on some articles first.")

    texts, labels, sample_weights = load_training_data(training_log_path)

    if len(texts) < min_samples:
        raise ValueError(
            f"Only {len(texts)} labeled articles so far -- need at least "
            f"{min_samples} before training produces a stable filter."
        )

    if len(set(labels)) < 2:
        raise ValueError(
            "All your swipes so far are the same label (all relevant or all "
            "not relevant). Swipe on at least one of each before training."
        )

    # Unigrams only, on purpose: keeps the exported model a simple
    # word -> weight map that's easy to read, edit by hand, and re-implement
    # anywhere without needing sklearn.
    vectorizer = TfidfVectorizer(
        lowercase=True,
        stop_words="english",
        ngram_range=(1, 1),
        min_df=2,  # ignore words that only appeared once (mostly noise)
        max_features=8000,
    )
    X = vectorizer.fit_transform(texts)

    model = LogisticRegression(max_iter=1000, class_weight="balanced")
    # class_weight="balanced" corrects for having more/fewer relevant vs.
    # not-relevant swipes overall; sample_weight then additionally boosts
    # individual "loved" rows on top of that. sklearn combines the two
    # automatically (they multiply per-sample).
    model.fit(X, labels, sample_weight=sample_weights)

    vocab = vectorizer.get_feature_names_out()
    coefs = model.coef_[0]

    weights = {word: round(float(coef), 5) for word, coef in zip(vocab, coefs)}
    # Drop near-zero weights -- they add noise to the exported file without
    # meaningfully affecting scoring.
    weights = {w: c for w, c in weights.items() if abs(c) > 1e-4}

    loved_count = sum(1 for w in sample_weights if w > 1.0)

    output = {
        "bias": float(model.intercept_[0]),
        "weights": weights,
        "trained_on": len(texts),
        "relevant_count": sum(labels),
        "not_relevant_count": len(labels) - sum(labels),
        "loved_count": loved_count,
        "trained_at": datetime.now(timezone.utc).isoformat(),
    }

    with open(weights_out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

    top_positive = sorted(weights.items(), key=lambda kv: -kv[1])[:15]
    top_negative = sorted(weights.items(), key=lambda kv: kv[1])[:15]

    return {
        "trained_on": len(texts),
        "relevant_count": sum(labels),
        "not_relevant_count": len(labels) - sum(labels),
        "loved_count": loved_count,
        "vocab_size": len(weights),
        "top_positive_keywords": top_positive,
        "top_negative_keywords": top_negative,
    }
