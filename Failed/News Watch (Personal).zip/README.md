# News Watch — Part 1: Filter Trainer

This is the training half of the two-part project. It fetches articles
from your RSS feeds, lets you swipe them relevant / not relevant in a
browser, and turns your swipes into a weighted-keyword filter file that
Part 2 (`news_watch.py`, built separately) will read.

## Setup

```bash
pip install -r requirements.txt
```

## Configure your feeds

Edit `feeds.json` — one list of RSS/XML feed URLs. Add or remove as many
as you like; more feeds means more variety to train on and less risk of
the model just learning one outlet's writing style. Restart the server
after editing.

## Run it

```bash
python3 filter_trainer.py
```

Then open **http://127.0.0.1:5050**.

## How it works

- **Swiping**: drag a card right (or press → / tap ♥) for "relevant,"
  left (or ← / ✕) for "not relevant." Clicking the headline opens the
  original article in a new tab and does not count as a swipe. The next
  few articles' images preload in the background so scrolling stays
  smooth.
- **Every swipe is logged** to `data/training_data.jsonl` — one JSON line
  per article, permanently. This file is never overwritten, so you can
  always retrain from scratch and never lose history.
- **Training**: once you've labeled at least 20 articles (with at least
  one of each label), the "Train filter" button becomes active. Clicking
  it fits a bag-of-words logistic regression on everything you've swiped
  so far and exports the result to `data/filter_weights.json` — a plain
  JSON map of `word -> weight`, plus a bias term. You can open that file
  in any text editor; the weights are meant to be human-readable.
- Articles you've already swiped on won't be shown to you again, even
  across restarts (dedup is by URL).

## On sample size

20 is the floor to get something non-degenerate — expect it to feel
rough. Filtering quality improves noticeably by ~200-300 swipes, and
keeps improving gradually after that. Re-run "Train filter" any time
after a swiping session; it always retrains from your complete history,
so there's no harm in doing it often.

## Files

```
feeds.json                    <- you edit this
filter_trainer.py             <- Flask server (run this)
train_filter.py               <- training logic (sklearn, isolated here)
static/index.html             <- the swipe UI
data/training_data.jsonl      <- your swipe history (append-only)
data/filter_weights.json      <- exported filter (Part 2 reads this)
```

## Note on testing

I built and tested this in a sandboxed environment that can't reach the
actual news domains in `feeds.json` (its network allowlist is
restricted to package registries like PyPI). The Flask server, the swipe
UI, the label logging, and the full sklearn training pipeline are all
verified working end-to-end against synthetic data. Fetching your real
feeds and extracting images from their specific XML will get its first
real test on your machine — if a particular feed's images don't show up,
it's likely a quirk of that feed's XML structure and worth flagging so I
can adjust the `extract_image` logic.
