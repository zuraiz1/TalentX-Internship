"""
poster_logo_batch.py — One-file tool that batch-adds the Abacus logo to every
poster in a "To be processed" folder and saves results into a "Finished" folder.

Everything is self-contained in this one file: format handling (PNG, JPEG,
WEBP, TIFF, BMP, PDF), multi-page PDF support, background-color detection,
and the folder queue/batch workflow.

WHAT IT DOES:
1. Makes the "To be processed" and "Finished" folders if they don't exist yet
   (on a first run with no input folder, it creates it and stops so you can
   drop files in, then re-run)
2. If the folders already exist, queues every supported file sitting in
   "To be processed"
3. Adds the logo to each file and saves the result into "Finished" under the
   same filename and file type (multi-page PDFs stay multi-page PDFs)

USAGE:
    python poster_logo_batch.py logo.png
    python poster_logo_batch.py logo.png "My Input Folder" "My Output Folder"   (optional overrides)

REQUIREMENTS:
    pip install Pillow PyMuPDF --break-system-packages
"""

import os
from PIL import Image, ImageDraw

try:
    import pymupdf  # for reading PDF input
except ImportError:
    pymupdf = None


# ============================== CONFIG ==============================

DEFAULT_INPUT_FOLDER = "To be processed"
DEFAULT_OUTPUT_FOLDER = "Finished"
DEFAULT_LOGO_NAME = "logo.png"

# Folders (and the logo) are resolved relative to THIS script file, not relative to
# whatever directory happened to be active when it was launched — this is what makes
# double-clicking the script work correctly regardless of where it's opened from.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".tiff", ".tif", ".bmp", ".pdf"}

# Reserved logo box, as a fraction of the full canvas (0.0-1.0), flush top-right
BOX_WIDTH_PCT = 0.15
BOX_HEIGHT_PCT = 0.10
LOGO_INNER_PADDING_PCT = 0.12   # padding inside the box around the logo itself

# Band used to sample the background color, as a fraction of canvas height. This sits
# in the intro-paragraph zone below the header and above the first info block — the one
# part of the template that's reliably plain background across every layout, unlike the
# corners (which can catch a decorative accent shape) or the footer/bottom edge (which
# can catch the takeaway banner or a stray decorative bar some generations add there).
BG_SAMPLE_BAND_TOP_PCT = 0.24
BG_SAMPLE_BAND_BOTTOM_PCT = 0.34

PDF_RENDER_DPI = 300        # resolution used when rasterizing PDF pages for editing
PDF_SAVE_DPI = 300          # resolution embedded when saving the result back to PDF
JPEG_QUALITY = 95           # only used when saving to .jpg/.jpeg

# ======================================================================


def _load_pages(path: str) -> list:
    """Open any supported input as a list of RGBA PIL Images (one per page).
    Non-PDF formats always return a list of length 1."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        if pymupdf is None:
            raise RuntimeError(
                "PDF input requires PyMuPDF. Install with: "
                "pip install PyMuPDF --break-system-packages"
            )
        doc = pymupdf.open(path)
        zoom = PDF_RENDER_DPI / 72  # PDF's native unit is 72 DPI
        matrix = pymupdf.Matrix(zoom, zoom)
        pages = []
        for page in doc:
            pix = page.get_pixmap(matrix=matrix, alpha=False)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            pages.append(img.convert("RGBA"))
        doc.close()
        return pages
    else:
        return [Image.open(path).convert("RGBA")]


def _process_page(poster: Image.Image, logo: Image.Image) -> Image.Image:
    """Run the logo-placement logic on a single page/image. Returns a new RGBA image."""
    poster = poster.copy()
    canvas_w, canvas_h = poster.size

    box_w = int(canvas_w * BOX_WIDTH_PCT)
    box_h = int(canvas_h * BOX_HEIGHT_PCT)
    box_x1 = canvas_w - box_w
    box_y1 = 0
    box_x2 = canvas_w
    box_y2 = box_h

    # Sample the background color from the intro-paragraph band using the most common
    # color in that band (downsampled first) — resistant to landing on a decorative
    # shape/banner AND to landing on individual dark text characters within the paragraph.
    band_top = int(canvas_h * BG_SAMPLE_BAND_TOP_PCT)
    band_bottom = int(canvas_h * BG_SAMPLE_BAND_BOTTOM_PCT)
    band = poster.crop((0, band_top, canvas_w, band_bottom)).convert("RGB")
    small = band.resize((150, 15))
    colors = small.getcolors(150 * 15)
    colors.sort(reverse=True)
    fill_color = colors[0][1] + (255,)

    draw = ImageDraw.Draw(poster)
    draw.rectangle([box_x1, box_y1, box_x2, box_y2], fill=fill_color)

    # Scale the logo to fit inside the box, respecting inner padding, preserving aspect ratio
    pad_w = int(box_w * LOGO_INNER_PADDING_PCT)
    pad_h = int(box_h * LOGO_INNER_PADDING_PCT)
    max_logo_w = box_w - 2 * pad_w
    max_logo_h = box_h - 2 * pad_h

    logo_ratio = logo.width / logo.height
    box_ratio = max_logo_w / max_logo_h

    if logo_ratio > box_ratio:
        new_w = max_logo_w
        new_h = int(new_w / logo_ratio)
    else:
        new_h = max_logo_h
        new_w = int(new_h * logo_ratio)

    logo_resized = logo.resize((new_w, new_h), Image.LANCZOS)

    paste_x = box_x1 + (box_w - new_w) // 2
    paste_y = box_y1 + (box_h - new_h) // 2
    poster.paste(logo_resized, (paste_x, paste_y), logo_resized)

    print(f"  Background fill used: RGB{fill_color[:3]} | Logo box: ({box_x1},{box_y1}) to ({box_x2},{box_y2})")
    return poster


def _save_single(rgb_img: Image.Image, path: str, ext: str) -> None:
    if ext == ".pdf":
        rgb_img.save(path, "PDF", resolution=PDF_SAVE_DPI)
    elif ext in (".jpg", ".jpeg"):
        rgb_img.save(path, "JPEG", quality=JPEG_QUALITY)
    else:
        rgb_img.save(path)


def _save_pages(pages: list, output_path: str) -> None:
    """Save one or more processed pages, choosing single-file vs multi-file vs
    multi-page-PDF automatically based on page count and output extension."""
    ext = os.path.splitext(output_path)[1].lower()
    rgb_pages = [p.convert("RGB") for p in pages]

    if len(rgb_pages) == 1:
        _save_single(rgb_pages[0], output_path, ext)
        print(f"Saved: {output_path}")
        return

    if ext == ".pdf":
        first, rest = rgb_pages[0], rgb_pages[1:]
        first.save(output_path, "PDF", save_all=True, append_images=rest, resolution=PDF_SAVE_DPI)
        print(f"Saved {len(rgb_pages)}-page PDF: {output_path}")
    else:
        stem, suffix = os.path.splitext(output_path)
        for i, page in enumerate(rgb_pages, start=1):
            page_path = f"{stem}_page{i}{suffix}"
            _save_single(page, page_path, ext)
            print(f"Saved page {i}/{len(rgb_pages)}: {page_path}")


def add_logo(poster_path: str, logo_path: str, output_path: str) -> None:
    """Process a single poster file (any supported format, including multi-page PDF)
    and save the result to output_path."""
    pages = _load_pages(poster_path)
    logo = Image.open(logo_path).convert("RGBA")

    print(f"Loaded {len(pages)} page(s) from {poster_path}")
    processed = []
    for i, page in enumerate(pages, start=1):
        print(f"Processing page {i}/{len(pages)}...")
        processed.append(_process_page(page, logo))

    _save_pages(processed, output_path)


def run_batch(logo_path: str, input_folder: str, output_folder: str) -> None:
    """Folder-based batch workflow: queue everything in input_folder, process it,
    save into output_folder. Creates both folders if missing."""
    # Resolve relative paths against the script's own location, not the current
    # working directory — see SCRIPT_DIR comment above for why
    if not os.path.isabs(input_folder):
        input_folder = os.path.join(SCRIPT_DIR, input_folder)
    if not os.path.isabs(output_folder):
        output_folder = os.path.join(SCRIPT_DIR, output_folder)
    if not os.path.isabs(logo_path):
        logo_path = os.path.join(SCRIPT_DIR, logo_path)

    created_input = False
    if not os.path.isdir(input_folder):
        os.makedirs(input_folder)
        created_input = True
    if not os.path.isdir(output_folder):
        os.makedirs(output_folder)

    if created_input:
        print(f"Created folder: {input_folder}")
        print(f"Created folder: {output_folder}")
        print(f"Drop your poster files into '{input_folder}' and run this script again.")
        return

    if not os.path.isfile(logo_path):
        print(f"Logo file not found: {logo_path}")
        return

    print(f"Input folder:  {input_folder}")
    print(f"Output folder: {output_folder}\n")

    entries = sorted(os.listdir(input_folder))
    files = [
        f for f in entries
        if os.path.isfile(os.path.join(input_folder, f))
        and not f.startswith(".")
        and os.path.splitext(f)[1].lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:
        print(f"No supported files found in '{input_folder}'.")
        print(f"Supported types: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")
        return

    print(f"Found {len(files)} file(s) to process.\n")

    succeeded, failed = [], []
    for filename in files:
        input_path = os.path.join(input_folder, filename)
        output_path = os.path.join(output_folder, filename)
        print(f"[{filename}]")
        try:
            add_logo(input_path, logo_path, output_path)
            succeeded.append(filename)
        except Exception as e:
            print(f"  FAILED: {e}")
            failed.append(filename)
        print()

    print("=" * 50)
    print(f"Done. {len(succeeded)} succeeded, {len(failed)} failed.")
    if failed:
        print("Failed files:")
        for f in failed:
            print(f"  - {f}")


def main() -> None:
    print("=== Abacus Poster Logo Batch Tool ===\n")

    logo_input = input(f"Logo filename (press Enter for default '{DEFAULT_LOGO_NAME}'): ").strip()
    logo_filename = logo_input if logo_input else DEFAULT_LOGO_NAME
    logo_path = (
        logo_filename if os.path.isabs(logo_filename)
        else os.path.join(SCRIPT_DIR, logo_filename)
    )
    print()

    run_batch(logo_path, DEFAULT_INPUT_FOLDER, DEFAULT_OUTPUT_FOLDER)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nSomething went wrong: {e}")
    finally:
        # Keeps the window open when double-clicked instead of flashing shut the
        # instant the script finishes — without this, you'd never see the output.
        # Wrapped in try/except so it exits cleanly even if stdin isn't available
        # for some reason, instead of showing a crash traceback on the way out.
        try:
            input("\nPress Enter to close...")
        except EOFError:
            pass