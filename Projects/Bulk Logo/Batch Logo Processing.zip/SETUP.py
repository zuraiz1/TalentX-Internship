"""
setup.py — One-time setup for the Poster Logo Batch Tool.

Just double-click this file once, before using poster_logo_batch.py for the
first time. It installs the two add-ons the tool needs (Pillow and PyMuPDF)
and tells you clearly whether it worked.

You do not need to understand what this does — just run it once and follow
what it prints.
"""

import subprocess
import sys

PACKAGES = ["Pillow", "PyMuPDF"]


def _run_pip_install(extra_flag: bool = False) -> subprocess.CompletedProcess:
    cmd = [sys.executable, "-m", "pip", "install"] + PACKAGES
    if extra_flag:
        cmd.append("--break-system-packages")
    return subprocess.run(cmd, capture_output=True, text=True)


def main() -> None:
    print("=== Poster Logo Tool — Setup ===\n")
    print("Installing required components (Pillow, PyMuPDF)...")
    print("This may take a minute. Please wait.\n")

    result = _run_pip_install(extra_flag=False)

    # Some systems (mainly Linux) block plain pip installs and need an extra
    # flag — if the first attempt failed for that specific reason, quietly
    # retry with it rather than bothering the user with the detail.
    if result.returncode != 0 and "externally-managed-environment" in result.stderr:
        result = _run_pip_install(extra_flag=True)

    if result.returncode == 0:
        print("Setup finished successfully.")
        print("You're all set — you can now use poster_logo_batch.py normally.\n")
    else:
        print("Something went wrong during setup.\n")
        print("Here's the technical detail, in case you need to share it")
        print("with whoever supports this tool for you:\n")
        print(result.stderr.strip()[-800:])  # tail of the error, most relevant part
        print("\nCommon fixes:")
        print("  - Make sure you're connected to the internet")
        print("  - Make sure Python was installed with 'pip' included")
        print("    (this is checked by default on the normal installer)")

    # Confirm things actually import correctly, regardless of what pip reported
    print("\nDouble-checking the install...")
    ok = True
    try:
        import PIL  # noqa: F401
        print("  Pillow: OK")
    except ImportError:
        print("  Pillow: NOT FOUND")
        ok = False
    try:
        import pymupdf  # noqa: F401
        print("  PyMuPDF: OK")
    except ImportError:
        print("  PyMuPDF: NOT FOUND")
        ok = False

    print()
    if ok:
        print("Everything is ready. You can close this window and start using the tool.")
    else:
        print("Setup did not fully complete. Please try running this file again,")
        print("or ask for help if the problem continues.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nSetup ran into an unexpected problem: {e}")
    finally:
        try:
            input("\nPress Enter to close...")
        except EOFError:
            pass