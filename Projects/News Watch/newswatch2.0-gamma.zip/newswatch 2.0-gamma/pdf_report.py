"""
pdf_report.py - renders the daily brief as a formatted PDF.

Layout:
    - Cover section: title, date, article count, active watchlist summary
    - Watchlist section: one highlighted block per active watchlist topic,
      with its matching articles (only shown if there's coverage). This
      spans both scopes - a war or protest you're tracking matters
      regardless of which desk covered it.
    - Local News division: topic sections built from local-scope sources
    - International News division: topic sections built from
      international-scope sources
    - Each article: bold headline (linked), source + published date,
      one-line LLM summary, and a note if multiple outlets covered it
      (cluster size > 1) - since that's a decent proxy for "how big a story"
"""

import time
from datetime import datetime
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, PageBreak
)
from reportlab.lib.enums import TA_LEFT


def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle("BriefTitle", parent=ss["Title"], fontSize=26, spaceAfter=6))
    ss.add(ParagraphStyle("BriefSubtitle", parent=ss["Normal"], fontSize=12, textColor=colors.HexColor("#555555")))
    ss.add(ParagraphStyle("DivisionHeader", parent=ss["Heading1"], fontSize=20,
                           textColor=colors.white, spaceBefore=4, spaceAfter=4))
    ss.add(ParagraphStyle("SectionHeader", parent=ss["Heading1"], fontSize=16,
                           textColor=colors.HexColor("#1a1a2e"), spaceBefore=18, spaceAfter=8))
    ss.add(ParagraphStyle("WatchlistHeader", parent=ss["Heading2"], fontSize=13,
                           textColor=colors.HexColor("#9c1c1c"), spaceBefore=10, spaceAfter=4))
    ss.add(ParagraphStyle("Headline", parent=ss["Normal"], fontSize=11, leading=14,
                           textColor=colors.HexColor("#0b3d91"), spaceAfter=2))
    ss.add(ParagraphStyle("Meta", parent=ss["Normal"], fontSize=8.5,
                           textColor=colors.HexColor("#777777"), spaceAfter=2))
    ss.add(ParagraphStyle("Body", parent=ss["Normal"], fontSize=10, leading=13, spaceAfter=10))
    return ss


def _article_flowables(styles, article, cluster_sizes):
    flows = []
    title = article["title"].replace("&", "&amp;")
    url = article["canonical_url"]
    flows.append(Paragraph(f'<a href="{url}" color="#0b3d91"><b>{title}</b></a>', styles["Headline"]))

    pub = article.get("published_at")
    pub_str = datetime.fromtimestamp(pub).strftime("%b %d, %Y %H:%M") if pub else "unknown date"
    coverage = cluster_sizes.get(article["cluster_id"], 1)
    coverage_note = f" &nbsp;|&nbsp; covered by {coverage} outlets" if coverage > 1 else ""
    flows.append(Paragraph(f"{article['source']} &nbsp;|&nbsp; {pub_str}{coverage_note}", styles["Meta"]))

    summary = article.get("llm_summary") or ""
    if summary:
        flows.append(Paragraph(summary, styles["Body"]))
    flows.append(Spacer(1, 4))
    return flows


def _build_markets_table(styles, market_readings):
    """A compact table of the latest market/commodity readings, pulled
    from whatever markets.py last wrote to the DB - collection cadence
    (markets-check, run independently on its own cron) and report cadence
    (this PDF, once daily) are deliberately decoupled, so this just reads
    the latest row per key rather than fetching anything itself."""
    header = ["Indicator", "Value", "Change"]
    rows = [header]
    for r in market_readings:
        unit = f" {r['unit']}" if r.get("unit") else ""
        value_str = f"{r['value']:,.2f}{unit}"
        if r.get("delta") is None:
            change_str = "—"
        else:
            sign = "+" if r["delta"] >= 0 else ""
            pct = f" ({sign}{r['delta_pct']:.1f}%)" if r.get("delta_pct") is not None else ""
            change_str = f"{sign}{r['delta']:,.2f}{pct}"
        rows.append([r["label"], value_str, change_str])

    t = Table(rows, colWidths=[2.7 * inch, 2.0 * inch, 1.8 * inch])
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f9")]),
    ]
    # Color deltas green/red once we know which data rows are which.
    for i, r in enumerate(market_readings, start=1):
        if r.get("delta") is not None:
            color = colors.HexColor("#1a7a2e") if r["delta"] >= 0 else colors.HexColor("#9c1c1c")
            style.append(("TEXTCOLOR", (2, i), (2, i), color))
    t.setStyle(TableStyle(style))
    return t


def _division_flowable(styles, title, bg_color):
    """A full-width colored band marking the start of a Local/International
    division, so the two are visually distinct at a glance, not just
    separated by a text header."""
    t = Table([[Paragraph(title, styles["DivisionHeader"])]], colWidths=[6.5 * inch])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg_color),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    return t


def _render_topic_sections(story, styles, sections, cluster_sizes):
    for sec in sections:
        story.append(Paragraph(sec["topic"].title(), styles["SectionHeader"]))
        if sec.get("intro"):
            story.append(Paragraph(sec["intro"], styles["Body"]))
        for art in sec["articles"]:
            story.extend(_article_flowables(styles, art, cluster_sizes))
        story.append(Spacer(1, 6))


def build_pdf(output_path, brief_date, watchlist_sections, local_sections, international_sections,
              cluster_sizes, total_considered, total_included, market_readings=None):
    """
    watchlist_sections:     list of dicts {topic, category, ttl_str, articles: [...], intro: str}
    local_sections:         list of dicts {topic, articles: [...], intro: str} - local-scope only
    international_sections: list of dicts {topic, articles: [...], intro: str} - international-scope only
    market_readings:        optional list of dicts from db.latest_market_readings() - the
                             KSE-100/crude/fuel snapshot markets.py last wrote. Omitted entirely
                             (no section, no blank space) if None or empty, so this stays a
                             no-op for callers that don't use the markets module.
    """
    doc = SimpleDocTemplate(
        output_path, pagesize=LETTER,
        topMargin=0.75 * inch, bottomMargin=0.75 * inch,
        leftMargin=0.75 * inch, rightMargin=0.75 * inch,
    )
    styles = _styles()
    story = []

    # ---- Cover ----
    story.append(Paragraph("NewsWatch Daily Brief", styles["BriefTitle"]))
    story.append(Paragraph(brief_date, styles["BriefSubtitle"]))
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#cccccc")))
    story.append(Spacer(1, 10))

    stats_table = Table(
        [["Articles considered", "Articles briefed", "Watchlist topics active"],
         [str(total_considered), str(total_included), str(len(watchlist_sections))]],
        colWidths=[1.9 * inch] * 3,
    )
    stats_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
    ]))
    story.append(stats_table)
    story.append(Spacer(1, 16))

    # ---- Markets (optional - only present if markets.py has ever run) ----
    if market_readings:
        story.append(Paragraph("Markets", styles["SectionHeader"]))
        story.append(_build_markets_table(styles, market_readings))
        story.append(Spacer(1, 16))

    # ---- Watchlist sections (highlighted, always first, spans both scopes) ----
    if watchlist_sections:
        story.append(Paragraph("Watchlist", styles["SectionHeader"]))
        for sec in watchlist_sections:
            header = f"{sec['topic']}  <font size=9 color='#9c1c1c'>[{sec['category']} - {sec['ttl_str']}]</font>"
            story.append(Paragraph(header, styles["WatchlistHeader"]))
            if sec.get("intro"):
                story.append(Paragraph(sec["intro"], styles["Body"]))
            if sec["articles"]:
                for art in sec["articles"]:
                    story.extend(_article_flowables(styles, art, cluster_sizes))
            else:
                story.append(Paragraph("No new coverage in this cycle.", styles["Meta"]))
            story.append(Spacer(1, 6))
        story.append(Spacer(1, 8))

    # ---- Local News division ----
    if local_sections:
        story.append(_division_flowable(styles, "Local News", colors.HexColor("#1a5d1a")))
        story.append(Spacer(1, 6))
        _render_topic_sections(story, styles, local_sections, cluster_sizes)

    # ---- International News division ----
    if international_sections:
        story.append(_division_flowable(styles, "International News", colors.HexColor("#1a1a5d")))
        story.append(Spacer(1, 6))
        _render_topic_sections(story, styles, international_sections, cluster_sizes)

    if not watchlist_sections and not local_sections and not international_sections:
        story.append(Paragraph("No articles cleared both filter stages in this cycle.", styles["Body"]))

    doc.build(story)
    return output_path
