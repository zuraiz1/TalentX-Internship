"""
scraper.py - pulls RSS feeds and loads new items into the DB.

Exact-duplicate rejection happens for free via db.insert_article() and the
UNIQUE constraint on url_hash (see dedup.py for URL canonicalization).
Near-duplicate clustering happens afterwards, in dedup.cluster_new_articles().
"""

import time
import feedparser
from dateutil import parser as dateparser

from dedup import url_hash, canonicalize_url


def _parse_published(entry):
    # Prefer feedparser's own normalized struct_time fields - it already
    # handles the many inconsistent RSS/Atom date formats feeds use in the
    # wild far more reliably than re-parsing the raw string ourselves.
    for key in ("published_parsed", "updated_parsed"):
        val = entry.get(key)
        if val:
            try:
                return int(time.mktime(val))
            except Exception:
                continue
    for key in ("published", "updated", "pubDate"):
        val = entry.get(key)
        if val:
            try:
                return int(dateparser.parse(val).timestamp())
            except Exception:
                continue
    # No usable date at all - fall back to "now". This is a deliberate
    # trade-off: an undated article will pass the freshness filter (see
    # filters.py) even if it's actually old, since we have no signal either
    # way. Feeds that reliably provide dates won't hit this path.
    return int(time.time())


def scrape_all(db, config, verbose=True):
    """Fetch every source in config, insert new articles.
    Returns (fetched_count, inserted_count)."""
    fetched = 0
    inserted = 0

    for source in config["sources"]:
        name = source["name"]
        url = source["url"]
        scope = source.get("scope", "international")
        if scope not in ("local", "international"):
            if verbose:
                print(f"  [!] {name}: unknown scope '{scope}', defaulting to 'international'")
            scope = "international"
        try:
            feed = feedparser.parse(url)
        except Exception as e:
            if verbose:
                print(f"  [!] Failed to fetch {name}: {e}")
            continue

        if getattr(feed, "bozo", False) and not feed.entries:
            if verbose:
                print(f"  [!] {name}: feed parse error / no entries")
            continue

        source_new = 0
        for entry in feed.entries:
            fetched += 1
            link = entry.get("link")
            title = entry.get("title", "").strip()
            if not link or not title:
                continue

            summary_raw = entry.get("summary", "") or entry.get("description", "")
            published_at = _parse_published(entry)

            article_id = db.insert_article(
                url_hash=url_hash(link),
                canonical_url=canonicalize_url(link),
                title=title,
                summary_raw=summary_raw,
                source=name,
                published_at=published_at,
                scope=scope,
            )
            if article_id is not None:
                inserted += 1
                source_new += 1

        if verbose:
            print(f"  {name}: {len(feed.entries)} items, {source_new} new")

    return fetched, inserted
