"""
llm.py - all calls to the local Ollama instance running llama3.1:8b.

Two jobs:
    1. classify_batch()  - stage 2 filtering. Takes articles that already
       survived the cheap keyword filter (filters.py) and asks the model to
       judge real relevance, assign topic tags, flag watchlist matches, and
       write a one-line summary - all in ONE call per batch (default 8
       articles/call) to minimize round-trips on limited local hardware.
    2. summarize_section() - used when building the PDF, to write a short
       paragraph introducing each topic section (2-4 sentences), given the
       headlines/summaries of the articles in it.

Everything is asked for as strict JSON and parsed defensively, because 8B
models occasionally wrap JSON in prose or code fences.
"""

import json
import re
import time
import requests


def _extract_json(text):
    """Pull the first JSON object/array out of a model response, tolerating
    ```json fences or stray prose around it."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?", "", text.strip())
    text = re.sub(r"```$", "", text.strip())
    text = text.strip()
    # find first [ or { and matching last ] or }
    start_candidates = [i for i in (text.find("["), text.find("{")) if i != -1]
    if not start_candidates:
        raise ValueError("no JSON found in LLM response")
    start = min(start_candidates)
    end_candidates = [i for i in (text.rfind("]"), text.rfind("}")) if i != -1]
    end = max(end_candidates) + 1
    return json.loads(text[start:end])


class OllamaClient:
    def __init__(self, config):
        llm_cfg = config["llm"]
        self.base_url = llm_cfg["base_url"].rstrip("/")
        self.model = llm_cfg["model"]
        self.timeout = llm_cfg.get("timeout_seconds", 120)
        self.delay = llm_cfg.get("request_delay_seconds", 0.2)

    def _generate(self, prompt, temperature=0.1):
        resp = requests.post(
            f"{self.base_url}/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": temperature},
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        time.sleep(self.delay)
        return resp.json()["response"]

    def classify_batch(self, articles, watchlist_rows):
        """articles: list of dicts with id/title/summary_raw.
        Returns dict {article_id: {relevant, relevance_score, topics, summary, matched_watchlist_ids}}."""
        watchlist_desc = "\n".join(
            f"  id={w['id']}: {w['topic']} (category: {w['category']})" for w in watchlist_rows
        ) or "  (none currently active)"

        items_desc = "\n".join(
            f'  [{a["id"]}] TITLE: {a["title"]}\n      SUMMARY: {(a.get("summary_raw") or "")[:400]}'
            for a in articles
        )

        prompt = f"""You are a news triage assistant. For each article below, decide if it is
genuinely newsworthy (not ads, listicles, or filler) and produce a compact JSON result.

Active watchlist topics (flag an article's watchlist match if it clearly relates to one):
{watchlist_desc}

Articles:
{items_desc}

Respond with ONLY a JSON array, one object per article, no prose, no markdown fences:
[
  {{
    "id": <article id, integer>,
    "relevant": true or false,
    "relevance_score": <float 0.0-1.0, how significant/newsworthy this is>,
    "topics": [<short lowercase tags, e.g. "conflict", "politics", "economy", "protest", "disaster">],
    "summary": "<one sentence, neutral tone, under 30 words>",
    "matched_watchlist_ids": [<ids from the watchlist above this article relates to, or empty list>]
  }}
]"""

        raw = self._generate(prompt)
        try:
            parsed = _extract_json(raw)
        except (ValueError, json.JSONDecodeError):
            # fail-safe: if parsing fails, treat the whole batch as
            # "needs human eyes" rather than silently dropping it.
            return {
                a["id"]: {
                    "relevant": True,
                    "relevance_score": 0.5,
                    "topics": ["unclassified"],
                    "summary": a["title"],
                    "matched_watchlist_ids": [],
                }
                for a in articles
            }

        out = {}
        for item in parsed:
            try:
                aid = int(item["id"])
            except (KeyError, ValueError, TypeError):
                continue
            out[aid] = {
                "relevant": bool(item.get("relevant", False)),
                "relevance_score": float(item.get("relevance_score", 0.0)),
                "topics": item.get("topics", []) or [],
                "summary": item.get("summary", "") or "",
                "matched_watchlist_ids": item.get("matched_watchlist_ids", []) or [],
            }
        return out

    def summarize_section(self, section_title, articles):
        """Short intro paragraph for a PDF section, given its articles."""
        headlines = "\n".join(f"- {a['title']}" for a in articles[:12])
        prompt = f"""Write a brief, neutral 2-3 sentence overview paragraph summarizing the
state of "{section_title}" based on these recent headlines. No preamble, just the paragraph.

Headlines:
{headlines}"""
        try:
            return self._generate(prompt).strip()
        except Exception:
            return ""
