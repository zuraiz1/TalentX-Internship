#!/usr/bin/env python3
"""
interactive.py - a friendlier front end for NewsWatch.

Launch with:  python interactive.py   (or: python main.py shell)

Type "/" to see available commands with autocomplete (arrow keys + Tab/Enter
to pick, keeps typing to narrow down). This wraps the exact same db/briefing/
watchlist modules the plain CLI (main.py) uses - it's a presentation layer,
not a second implementation, so behavior always matches `python main.py run`
etc.
"""

import sys
import json
import yaml

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style

from db import DB
import watchlist as wl
import briefing

console = Console()

CATEGORIES = ["war", "protest", "march", "election", "disaster", "other"]

BANNER = r"""
[bold cyan] _   _                 __      __     _       _     [/]
[bold cyan]| \ | | _____      __ / /  \ \ / /_ _| |_ ___| |__  [/]
[bold cyan]|  \| |/ _ \ \ /\ / / \ \/\/ /| | ' \  _/ _/ | ' \\ [/]
[bold cyan]| |\  |  __/\ V  V /   \_/\_/ |_||_|_\_/\__| |_||_| [/]
[bold cyan]|_| \_|\___| \_/\_/       local · private · yours  [/]
"""

PROMPT_STYLE = Style.from_dict({
    "prompt": "bold ansicyan",
})

COMMAND_TREE = {
    "/run": None,
    "/watchlist": ["add", "list", "remove", "renew"],
    "/sources": ["list"],
    "/status": None,
    "/help": None,
    "/exit": None,
    "/quit": None,
}


class SlashCommandCompleter(Completer):
    """Matches the FULL token typed so far against command names, instead of
    relying on prompt_toolkit's default word-boundary splitting (which treats
    "/" as a separator and breaks partial matches like "/w" -> "/watchlist").
    Suggestions appear as soon as "/" is typed and narrow down from there."""

    def __init__(self, tree):
        self.tree = tree

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        if " " not in text:
            # completing the top-level command itself
            for cmd in self.tree:
                if cmd.startswith(text):
                    yield Completion(cmd, start_position=-len(text))
            return

        first, rest = text.split(" ", 1)
        options = self.tree.get(first)
        if not options:
            return
        # only handle one level of subcommand (e.g. "/watchlist add")
        sub_typed = rest.lstrip()
        # ids/args after the subcommand itself aren't completed
        if " " in sub_typed:
            return
        for opt in options:
            if opt.startswith(sub_typed):
                yield Completion(opt, start_position=-len(sub_typed))


class _FlatCompleter(Completer):
    """Simple full-token-prefix completer for single-level choice prompts
    (e.g. picking a watchlist category)."""

    def __init__(self, options):
        self.options = options

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        for opt in self.options:
            if opt.startswith(text):
                yield Completion(opt, start_position=-len(text))


def load_config(path="config.yaml"):
    with open(path) as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------- rendering

def render_help():
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan", title="Commands")
    table.add_column("Command")
    table.add_column("Does")
    rows = [
        ("/run", "Scrape, filter, classify, and build today's PDF brief"),
        ("/watchlist add", "Guided wizard to add a topic to track (with expiry)"),
        ("/watchlist list", "Show active watchlist topics and time remaining"),
        ("/watchlist remove <id>", "Deactivate a topic early"),
        ("/watchlist renew <id>", "Extend a topic's expiry"),
        ("/sources list", "Show configured RSS sources"),
        ("/status", "Quick database + watchlist summary"),
        ("/help", "Show this table"),
        ("/exit, /quit", "Leave the shell"),
    ]
    for cmd, desc in rows:
        table.add_row(f"[bold]{cmd}[/bold]", desc)
    console.print(table)
    console.print("[dim]Tip: type / and keep typing - suggestions narrow down as you go.[/dim]")


def render_watchlist(rows):
    if not rows:
        console.print("[yellow]No active watchlist topics.[/yellow]")
        return
    table = Table(box=box.ROUNDED, header_style="bold cyan", title="Active Watchlist")
    table.add_column("ID", justify="right")
    table.add_column("Topic")
    table.add_column("Category")
    table.add_column("Priority", justify="center")
    table.add_column("Expires")
    priority_colors = {1: "white", 2: "yellow", 3: "bold red"}
    for r in rows:
        pcolor = priority_colors.get(r["priority"], "white")
        table.add_row(
            str(r["id"]), r["topic"], r["category"],
            f"[{pcolor}]{r['priority']}[/{pcolor}]",
            wl.format_ttl(r["expires_at"]),
        )
    console.print(table)


def render_sources(config):
    table = Table(box=box.ROUNDED, header_style="bold cyan", title="RSS Sources")
    table.add_column("Name")
    table.add_column("Scope")
    table.add_column("URL")
    for s in config["sources"]:
        scope = s.get("scope", "international")
        scope_style = "green" if scope == "local" else "blue"
        table.add_row(s["name"], f"[{scope_style}]{scope}[/{scope_style}]", s["url"])
    console.print(table)


def render_status(db, config):
    with db.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM articles")
        total_articles = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM articles WHERE passed_stage2=1")
        relevant = cur.fetchone()[0]
        cur.execute("SELECT brief_date, pdf_path, article_count FROM briefs ORDER BY id DESC LIMIT 1")
        last_brief = cur.fetchone()

    active_wl = wl.list_active(db)
    body = Text()
    body.append(f"Articles in database: {total_articles}\n")
    body.append(f"Classified as relevant: {relevant}\n")
    body.append(f"Active watchlist topics: {len(active_wl)}\n")
    if last_brief:
        body.append(f"Last brief: {last_brief['brief_date']} "
                     f"({last_brief['article_count']} articles) -> {last_brief['pdf_path']}\n")
    else:
        body.append("Last brief: none yet - run /run to generate one\n")
    console.print(Panel(body, title="NewsWatch Status", border_style="cyan"))


# ------------------------------------------------------------------ actions

def action_run(db, config):
    console.print("[bold cyan]Starting a brief cycle...[/bold cyan] "
                   "[dim](scrape -> dedupe -> filter -> classify -> PDF)[/dim]")
    try:
        pdf_path = briefing.run_cycle(db, config, verbose=True)
    except Exception as e:
        console.print(f"[bold red]Run failed:[/bold red] {e}")
        return
    console.print(Panel(f"[bold green]Brief ready:[/bold green] {pdf_path}", border_style="green"))


def action_watchlist_add_wizard(db, config, session):
    console.print("[bold]New watchlist topic[/bold] [dim](Ctrl+C to cancel any time)[/dim]")
    try:
        topic = session.prompt("  Topic name (e.g. 'Sudan civil war'): ").strip()
        if not topic:
            console.print("[yellow]Cancelled - topic name required.[/yellow]")
            return
        keywords_raw = session.prompt("  Keywords, comma-separated (e.g. Sudan,RSF,Khartoum): ").strip()
        keywords = [k.strip() for k in keywords_raw.split(",") if k.strip()]
        if not keywords:
            console.print("[yellow]Cancelled - at least one keyword required.[/yellow]")
            return

        category = session.prompt(
            f"  Category {CATEGORIES}: ",
            completer=_FlatCompleter(CATEGORIES),
        ).strip() or "other"
        if category not in CATEGORIES:
            console.print(f"[yellow]Unknown category '{category}', using 'other'.[/yellow]")
            category = "other"

        ttl_raw = session.prompt("  Track for how many days? [14]: ").strip()
        ttl = int(ttl_raw) if ttl_raw else 14

        priority_raw = session.prompt("  Priority 1 (normal) - 3 (urgent) [1]: ").strip()
        priority = int(priority_raw) if priority_raw else 1
        priority = max(1, min(3, priority))
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Cancelled.[/yellow]")
        return

    wid = wl.add(db, topic, keywords, category, ttl, priority, config)
    console.print(Panel(
        f"[bold green]Added #{wid}[/bold green]: {topic}\n"
        f"Keywords: {', '.join(keywords)}\nCategory: {category}  Priority: {priority}  TTL: {ttl} days",
        border_style="green",
    ))


def action_watchlist_remove(db, arg):
    if not arg or not arg.strip().isdigit():
        console.print("[yellow]Usage: /watchlist remove <id>  (see /watchlist list for ids)[/yellow]")
        return
    wl.remove(db, int(arg.strip()))
    console.print(f"[green]Removed watchlist topic #{arg.strip()}[/green]")


def action_watchlist_renew(db, arg, session):
    if not arg or not arg.strip().isdigit():
        console.print("[yellow]Usage: /watchlist renew <id>[/yellow]")
        return
    ttl_raw = session.prompt("  Extend for how many days? [14]: ").strip()
    ttl = int(ttl_raw) if ttl_raw else 14
    wl.renew(db, int(arg.strip()), ttl)
    console.print(f"[green]Renewed watchlist topic #{arg.strip()} for {ttl} more days[/green]")


# -------------------------------------------------------------------- shell

def dispatch(line, db, config, session):
    line = line.strip()
    if not line:
        return True
    parts = line.split()
    cmd = parts[0]

    if cmd in ("/exit", "/quit"):
        return False

    if cmd == "/help":
        render_help()
    elif cmd == "/status":
        render_status(db, config)
    elif cmd == "/run":
        action_run(db, config)
    elif cmd == "/sources":
        if len(parts) >= 2 and parts[1] == "list":
            render_sources(config)
        else:
            console.print("[yellow]Did you mean /sources list ?[/yellow]")
    elif cmd == "/watchlist":
        sub = parts[1] if len(parts) >= 2 else None
        rest = " ".join(parts[2:]) if len(parts) > 2 else ""
        if sub == "add":
            action_watchlist_add_wizard(db, config, session)
        elif sub == "list":
            render_watchlist(wl.list_active(db))
        elif sub == "remove":
            action_watchlist_remove(db, rest)
        elif sub == "renew":
            action_watchlist_renew(db, rest, session)
        else:
            console.print("[yellow]Usage: /watchlist add|list|remove|renew[/yellow]")
    else:
        console.print(f"[yellow]Unknown command '{cmd}'. Type /help or press / for suggestions.[/yellow]")
    return True


def main(config_path="config.yaml"):
    console.print(BANNER)
    config = load_config(config_path)
    db = DB(config["output"]["db_path"])

    expired = wl.expire_stale(db, verbose=False)
    if expired:
        console.print(f"[dim]({len(expired)} watchlist topic(s) expired and were deactivated)[/dim]")

    completer = SlashCommandCompleter(COMMAND_TREE)
    session = PromptSession(
        history=FileHistory(".newswatch_history"),
        completer=completer,
        complete_while_typing=True,
        style=PROMPT_STYLE,
    )

    render_help()
    console.print()

    try:
        while True:
            try:
                line = session.prompt([("class:prompt", "newswatch> ")])
            except (KeyboardInterrupt, EOFError):
                break
            if not dispatch(line, db, config, session):
                break
    finally:
        db.close()
        console.print("[dim]Goodbye.[/dim]")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "config.yaml")
