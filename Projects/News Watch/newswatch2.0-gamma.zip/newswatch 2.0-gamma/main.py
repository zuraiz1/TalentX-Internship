#!/usr/bin/env python3
"""
NewsWatch CLI

    python main.py run                          -> scrape + filter + build today's PDF brief
    python main.py watchlist add "Sudan war" --keywords Sudan,RSF,Khartoum --category war --ttl 21 --priority 3
    python main.py watchlist list
    python main.py watchlist remove <id>
    python main.py watchlist renew <id> --ttl 14
    python main.py markets-check                -> fetch KSE-100/crude/fuel readings (own cron, decoupled from `run`)
    python main.py init-config                  -> prints path to the editable config.yaml
"""

import argparse
import sys
import yaml

from db import DB
import watchlist as wl
import briefing
import markets


def load_config(path="config.yaml"):
    with open(path) as f:
        return yaml.safe_load(f)


def cmd_run(args):
    config = load_config(args.config)
    db = DB(config["output"]["db_path"])
    try:
        briefing.run_cycle(db, config, verbose=True)
    finally:
        db.close()


def cmd_watchlist_add(args):
    config = load_config(args.config)
    db = DB(config["output"]["db_path"])
    try:
        keywords = [k.strip() for k in args.keywords.split(",") if k.strip()]
        wid = wl.add(db, args.topic, keywords, args.category, args.ttl, args.priority, config)
        print(f"Added watchlist topic #{wid}: '{args.topic}' "
              f"(keywords: {keywords}, category: {args.category}, ttl: {args.ttl} days, priority: {args.priority})")
    finally:
        db.close()


def cmd_watchlist_list(args):
    config = load_config(args.config)
    db = DB(config["output"]["db_path"])
    try:
        rows = wl.list_active(db)
        if not rows:
            print("No active watchlist topics.")
            return
        print(f"{'ID':<4} {'Topic':<30} {'Category':<12} {'Priority':<9} {'Expires'}")
        for r in rows:
            print(f"{r['id']:<4} {r['topic']:<30} {r['category']:<12} {r['priority']:<9} {wl.format_ttl(r['expires_at'])}")
    finally:
        db.close()


def cmd_watchlist_remove(args):
    config = load_config(args.config)
    db = DB(config["output"]["db_path"])
    try:
        wl.remove(db, args.id)
        print(f"Removed watchlist topic #{args.id}")
    finally:
        db.close()


def cmd_watchlist_renew(args):
    config = load_config(args.config)
    db = DB(config["output"]["db_path"])
    try:
        wl.renew(db, args.id, args.ttl)
        print(f"Renewed watchlist topic #{args.id} for {args.ttl} more days")
    finally:
        db.close()


def cmd_markets_check(args):
    config = load_config(args.config)
    db = DB(config["output"]["db_path"])
    try:
        print("Checking markets...")
        results = markets.run_check(db, config, verbose=True)
        if not results:
            print("No readings recorded - see warnings above.")
        else:
            print(f"\n{len(results)} reading(s) recorded.")
    finally:
        db.close()


def cmd_shell(args):
    import interactive
    interactive.main(args.config)


def cmd_init_config(args):
    print("Edit config.yaml (in this project folder) to set your RSS sources, "
          "region keywords, exclusions, and Ollama model settings.")


def build_parser():
    p = argparse.ArgumentParser(description="NewsWatch - local LLM news briefing tool")
    p.add_argument("--config", default="config.yaml", help="path to config.yaml")
    sub = p.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="scrape, filter, and build today's PDF brief")
    run_p.set_defaults(func=cmd_run)

    wl_p = sub.add_parser("watchlist", help="manage tracked topics")
    wl_sub = wl_p.add_subparsers(dest="wl_command", required=True)

    add_p = wl_sub.add_parser("add", help="add a topic to watch")
    add_p.add_argument("topic", help="e.g. 'Sudan civil war'")
    add_p.add_argument("--keywords", required=True, help="comma-separated, e.g. 'Sudan,RSF,Khartoum'")
    add_p.add_argument("--category", default="other", choices=["war", "protest", "march", "election", "disaster", "other"])
    add_p.add_argument("--ttl", type=int, default=14, help="days until this auto-expires")
    add_p.add_argument("--priority", type=int, default=1, choices=[1, 2, 3])
    add_p.set_defaults(func=cmd_watchlist_add)

    list_p = wl_sub.add_parser("list", help="list active topics")
    list_p.set_defaults(func=cmd_watchlist_list)

    rm_p = wl_sub.add_parser("remove", help="deactivate a topic early")
    rm_p.add_argument("id", type=int)
    rm_p.set_defaults(func=cmd_watchlist_remove)

    renew_p = wl_sub.add_parser("renew", help="extend a topic's expiry")
    renew_p.add_argument("id", type=int)
    renew_p.add_argument("--ttl", type=int, default=14, help="days from now")
    renew_p.set_defaults(func=cmd_watchlist_renew)

    markets_p = sub.add_parser("markets-check", help="fetch latest market/commodity readings (independent of the news brief)")
    markets_p.set_defaults(func=cmd_markets_check)

    init_p = sub.add_parser("init-config", help="show where the config file lives")
    init_p.set_defaults(func=cmd_init_config)

    shell_p = sub.add_parser("shell", help="launch the interactive shell with / command suggestions")
    shell_p.set_defaults(func=cmd_shell)

    return p


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
