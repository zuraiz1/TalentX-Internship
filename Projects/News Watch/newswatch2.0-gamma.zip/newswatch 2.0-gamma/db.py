"""
db.py - SQLite storage layer for NewsWatch.

Tables:
    articles    - every article ever seen, with dedup keys and LLM output
    watchlist   - topics being tracked (wars, protests, marches...), with TTL
    briefs      - one row per generated PDF brief
    brief_items - which articles went into which brief (and which section)

Design notes on dedup:
    - `url_hash` is a UNIQUE constraint -> exact re-fetch of the same URL
      (common when re-running the scraper) is rejected at the DB level for free.
    - `dedup_sig` (a token-set signature) is used for *near*-duplicate
      detection: the same real-world story reported by five different outlets
      with five different URLs and slightly different headlines. That
      comparison happens in dedup.py against a recent time window, not here.
    - `cluster_id` groups near-duplicate articles once dedup.py has run.
      Only one article per cluster (the "primary") is ever shown in a brief;
      the rest are kept in the DB (for provenance / "N outlets reported this")
      but marked is_primary = 0.
"""

import sqlite3
import json
import time
from contextlib import contextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url_hash TEXT UNIQUE NOT NULL,
    canonical_url TEXT NOT NULL,
    title TEXT NOT NULL,
    summary_raw TEXT,
    source TEXT,
    scope TEXT NOT NULL DEFAULT 'international',   -- 'local' or 'international', from the source's config
    published_at INTEGER,          -- unix timestamp, best-effort from feed
    fetched_at INTEGER NOT NULL,
    dedup_sig TEXT,                 -- stopword-filtered token-set signature, "word1|word2|..."
    cluster_id INTEGER,            -- FK-ish, groups near-duplicates
    is_primary INTEGER DEFAULT 1,  -- 1 = representative of its cluster
    passed_stage1 INTEGER DEFAULT 0,
    passed_stage2 INTEGER DEFAULT 0,
    relevance_score REAL,
    llm_summary TEXT,
    topics TEXT,                   -- JSON list of tags, e.g. ["conflict","politics"]
    matched_watchlist_ids TEXT,    -- JSON list of watchlist.id
    briefed_on TEXT                -- JSON list of brief_date strings this article appeared in
);

CREATE INDEX IF NOT EXISTS idx_articles_cluster ON articles(cluster_id);
CREATE INDEX IF NOT EXISTS idx_articles_fetched ON articles(fetched_at);
CREATE INDEX IF NOT EXISTS idx_articles_stage2 ON articles(passed_stage2);

CREATE TABLE IF NOT EXISTS watchlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL,
    keywords TEXT NOT NULL,        -- JSON list
    category TEXT,                 -- e.g. "war", "protest", "election"
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    priority INTEGER DEFAULT 1,    -- 1 (normal) - 3 (urgent), affects PDF ordering
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS briefs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    brief_date TEXT NOT NULL,
    pdf_path TEXT,
    created_at INTEGER NOT NULL,
    article_count INTEGER
);

CREATE TABLE IF NOT EXISTS brief_items (
    brief_id INTEGER NOT NULL,
    article_id INTEGER NOT NULL,
    section TEXT,
    PRIMARY KEY (brief_id, article_id)
);

-- Markets: fully decoupled from the articles/watchlist/brief tables above.
-- One row per (ticker key, reading). We keep history (not just "latest")
-- so delta-vs-last-reading is a real DB query, not a value carried in
-- memory between cron runs that don't share a process.
CREATE TABLE IF NOT EXISTS market_readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL,             -- config key, e.g. "kse100", "crude_wti"
    label TEXT NOT NULL,           -- display label, e.g. "KSE-100 Index"
    value REAL NOT NULL,
    unit TEXT,                     -- e.g. "PKR", "USD/bbl", "PKR/L"
    delta REAL,                    -- value - previous reading's value for this key (NULL on first-ever reading)
    delta_pct REAL,                -- delta / previous value * 100 (NULL if previous was 0 or missing)
    fetched_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_market_readings_key_time ON market_readings(key, fetched_at);
"""


class DB:
    def __init__(self, path):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    @contextmanager
    def cursor(self):
        cur = self.conn.cursor()
        try:
            yield cur
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            cur.close()

    # ---------------- articles ----------------

    def insert_article(self, url_hash, canonical_url, title, summary_raw, source, published_at, scope="international"):
        """Insert a raw scraped article. Returns the row id, or None if it's
        an exact duplicate (same url_hash already exists)."""
        try:
            with self.cursor() as cur:
                cur.execute(
                    """INSERT INTO articles
                       (url_hash, canonical_url, title, summary_raw, source, scope, published_at, fetched_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (url_hash, canonical_url, title, summary_raw, source, scope, published_at, int(time.time())),
                )
                return cur.lastrowid
        except sqlite3.IntegrityError:
            return None  # exact duplicate URL, already have it

    def recent_articles(self, since_ts, unclustered_only=False):
        q = "SELECT * FROM articles WHERE fetched_at >= ?"
        if unclustered_only:
            q += " AND cluster_id IS NULL"
        with self.cursor() as cur:
            cur.execute(q, (since_ts,))
            return [dict(r) for r in cur.fetchall()]

    def set_cluster(self, article_id, dedup_sig, cluster_id, is_primary):
        with self.cursor() as cur:
            cur.execute(
                "UPDATE articles SET dedup_sig=?, cluster_id=?, is_primary=? WHERE id=?",
                (dedup_sig, cluster_id, int(is_primary), article_id),
            )

    def set_primary(self, article_id, is_primary):
        with self.cursor() as cur:
            cur.execute("UPDATE articles SET is_primary=? WHERE id=?", (int(is_primary), article_id))

    def get_primary_of_cluster(self, cluster_id):
        with self.cursor() as cur:
            cur.execute("SELECT * FROM articles WHERE cluster_id=? AND is_primary=1 LIMIT 1", (cluster_id,))
            row = cur.fetchone()
            return dict(row) if row else None

    def next_cluster_id(self):
        with self.cursor() as cur:
            cur.execute("SELECT COALESCE(MAX(cluster_id), 0) + 1 FROM articles")
            return cur.fetchone()[0]

    def mark_stage1(self, article_id, passed):
        with self.cursor() as cur:
            cur.execute("UPDATE articles SET passed_stage1=? WHERE id=?", (int(passed), article_id))

    def save_llm_result(self, article_id, passed_stage2, relevance_score, summary, topics, matched_watchlist_ids):
        with self.cursor() as cur:
            cur.execute(
                """UPDATE articles SET passed_stage2=?, relevance_score=?, llm_summary=?,
                   topics=?, matched_watchlist_ids=? WHERE id=?""",
                (
                    int(passed_stage2),
                    relevance_score,
                    summary,
                    json.dumps(topics or []),
                    json.dumps(matched_watchlist_ids or []),
                    article_id,
                ),
            )

    def candidates_for_brief(self, since_ts):
        """Primary articles that passed both filter stages and haven't been
        briefed yet (or whose cluster has meaningfully grown - handled by caller)."""
        with self.cursor() as cur:
            cur.execute(
                """SELECT * FROM articles
                   WHERE fetched_at >= ? AND is_primary=1 AND passed_stage2=1
                   ORDER BY relevance_score DESC""",
                (since_ts,),
            )
            return [dict(r) for r in cur.fetchall()]

    def mark_briefed(self, article_id, brief_date):
        with self.cursor() as cur:
            cur.execute("SELECT briefed_on FROM articles WHERE id=?", (article_id,))
            row = cur.fetchone()
            existing = json.loads(row["briefed_on"]) if row and row["briefed_on"] else []
            if brief_date not in existing:
                existing.append(brief_date)
            cur.execute("UPDATE articles SET briefed_on=? WHERE id=?", (json.dumps(existing), article_id))

    def cluster_size(self, cluster_id):
        with self.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM articles WHERE cluster_id=?", (cluster_id,))
            return cur.fetchone()[0]

    # ---------------- watchlist ----------------

    def add_watchlist(self, topic, keywords, category, ttl_days, priority=1):
        now = int(time.time())
        expires = now + ttl_days * 86400
        with self.cursor() as cur:
            cur.execute(
                """INSERT INTO watchlist (topic, keywords, category, created_at, expires_at, priority, active)
                   VALUES (?, ?, ?, ?, ?, ?, 1)""",
                (topic, json.dumps(keywords), category, now, expires, priority),
            )
            return cur.lastrowid

    def list_watchlist(self, active_only=True):
        q = "SELECT * FROM watchlist"
        if active_only:
            q += " WHERE active=1"
        q += " ORDER BY priority DESC, expires_at ASC"
        with self.cursor() as cur:
            cur.execute(q)
            return [dict(r) for r in cur.fetchall()]

    def remove_watchlist(self, watchlist_id):
        with self.cursor() as cur:
            cur.execute("UPDATE watchlist SET active=0 WHERE id=?", (watchlist_id,))

    def renew_watchlist(self, watchlist_id, ttl_days):
        new_expiry = int(time.time()) + ttl_days * 86400
        with self.cursor() as cur:
            cur.execute("UPDATE watchlist SET expires_at=?, active=1 WHERE id=?", (new_expiry, watchlist_id))

    def expire_watchlist(self):
        """Deactivate any watchlist topic whose TTL has passed. This is what
        keeps the watchlist from silently growing forever and eating into
        every future LLM pass."""
        now = int(time.time())
        with self.cursor() as cur:
            cur.execute("SELECT id, topic FROM watchlist WHERE active=1 AND expires_at < ?", (now,))
            expired = [dict(r) for r in cur.fetchall()]
            cur.execute("UPDATE watchlist SET active=0 WHERE active=1 AND expires_at < ?", (now,))
        return expired

    # ---------------- briefs ----------------

    def create_brief(self, brief_date, pdf_path, article_count):
        with self.cursor() as cur:
            cur.execute(
                "INSERT INTO briefs (brief_date, pdf_path, created_at, article_count) VALUES (?, ?, ?, ?)",
                (brief_date, pdf_path, int(time.time()), article_count),
            )
            return cur.lastrowid

    def add_brief_item(self, brief_id, article_id, section):
        with self.cursor() as cur:
            cur.execute(
                "INSERT OR IGNORE INTO brief_items (brief_id, article_id, section) VALUES (?, ?, ?)",
                (brief_id, article_id, section),
            )

    # ---------------- markets ----------------

    def latest_market_reading(self, key):
        """Most recent reading for one ticker key, or None if never fetched.
        Orders by id (strictly increasing insert order), not fetched_at -
        two readings can land in the same second (e.g. a quick re-run), and
        fetched_at alone can't break that tie reliably."""
        with self.cursor() as cur:
            cur.execute(
                "SELECT * FROM market_readings WHERE key=? ORDER BY id DESC LIMIT 1",
                (key,),
            )
            row = cur.fetchone()
            return dict(row) if row else None

    def insert_market_reading(self, key, label, value, unit, delta, delta_pct, fetched_at=None):
        fetched_at = fetched_at if fetched_at is not None else int(time.time())
        with self.cursor() as cur:
            cur.execute(
                """INSERT INTO market_readings (key, label, value, unit, delta, delta_pct, fetched_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (key, label, value, unit, delta, delta_pct, fetched_at),
            )
            return cur.lastrowid

    def latest_market_readings(self, keys=None):
        """One row per key: whatever was most recently fetched for it.
        Used by the PDF builder - it only ever wants 'right now', not
        history. Grouped by MAX(id), not MAX(fetched_at): two readings for
        the same key can share a fetched_at second, and id (strictly
        increasing insert order) is the only reliable tiebreaker."""
        with self.cursor() as cur:
            if keys:
                placeholders = ",".join("?" * len(keys))
                cur.execute(
                    f"""SELECT r.* FROM market_readings r
                        INNER JOIN (
                            SELECT key, MAX(id) AS max_id
                            FROM market_readings WHERE key IN ({placeholders})
                            GROUP BY key
                        ) latest ON r.key = latest.key AND r.id = latest.max_id
                        ORDER BY r.key""",
                    keys,
                )
            else:
                cur.execute(
                    """SELECT r.* FROM market_readings r
                       INNER JOIN (
                           SELECT key, MAX(id) AS max_id FROM market_readings GROUP BY key
                       ) latest ON r.key = latest.key AND r.id = latest.max_id
                       ORDER BY r.key"""
                )
            return [dict(r) for r in cur.fetchall()]

    def close(self):
        self.conn.close()
