"""
dedup.py - the two layers of deduplication.

Layer 1: EXACT dedup via canonical URL hashing.
    Feeds re-publish the same URL on every fetch, and outlets add tracking
    params (?utm_source=..., ?fbclid=...) that would otherwise make identical
    URLs look different. We strip those before hashing. This layer is
    enforced by db.py's UNIQUE constraint on url_hash - it costs nothing and
    catches the majority of "duplicate" noise from re-scraping.

Layer 2: NEAR-duplicate dedup via a title-weighted overlap score (Ruzicka
    similarity over a weighted bag-of-words).
    The same real-world story ("Earthquake hits X") gets independently
    written by 5+ outlets with 5 different URLs and meaningfully different
    headlines ("Gaza ceasefire talks resume" vs "Ceasefire talks over Gaza
    resume"), and often quite different summary text even when the
    headlines closely match. A plain (unweighted) Jaccard over title+summary
    tokens turned out to under-cluster in practice: two headlines can share
    75% of their significant words while the surrounding summary text - which
    varies far more between outlets - dilutes that signal below threshold.
    Weighting title tokens several times heavier than summary tokens (via a
    weighted bag rather than a plain set, compared with Ruzicka similarity -
    the multiset generalization of Jaccard) fixes this: strong headline
    overlap dominates the score even when summaries diverge, while two
    articles that only share a generic word or two stay near zero.

    This still isn't magic - two articles about the same event can be
    headlined so differently ("Pilot's drug test positive" vs "Flight plunge
    under investigation") that no word-overlap method will link them without
    real semantic understanding. That's a known limitation; the LLM
    classification pass in llm.py doesn't currently cross-check against
    other articles in the same batch for this, but could be extended to.

    We only compare an article against others published within a rolling
    time window (default 72h) - old news can't match new arrivals, so this
    stays cheap: O(window_size) comparisons per new article, not O(all
    articles ever). For a personal news watch (hundreds-low thousands of
    items per window) that's trivial.

No external dependency: pure Python, no numpy/sklearn required.
"""

import hashlib
import re
from collections import Counter
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

_STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "of", "in", "on", "at", "to",
    "for", "with", "as", "by", "is", "are", "was", "were", "be", "been",
    "it", "its", "this", "that", "these", "those", "from", "into", "over",
    "after", "before", "amid", "amid", "than", "will", "has", "have", "had",
    "not", "no", "new", "says", "said", "up", "out", "about", "against",
}

TITLE_WEIGHT = 5       # each significant title word counts this many times
SUMMARY_TOKEN_CAP = 12  # only the first N significant summary words are used -
                        # enough to help disambiguate generic headlines,
                        # without letting a long, freely-paraphrased summary
                        # dilute a strong headline match

TRACKING_PARAMS = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "fbclid", "gclid", "ito", "cmp", "ns_campaign", "ns_mchannel", "ns_source",
    "intcid", "traffic_source", "CMP",
}

_word_re = re.compile(r"[a-z0-9]+")


def canonicalize_url(url):
    """Strip tracking params and fragment, lowercase scheme/host, drop trailing slash."""
    parts = urlsplit(url.strip())
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True) if k not in TRACKING_PARAMS]
    path = parts.path.rstrip("/") or "/"
    clean = urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, urlencode(query), ""))
    return clean


def url_hash(url):
    return hashlib.sha256(canonicalize_url(url).encode("utf-8")).hexdigest()


def _tokenize(text):
    words = _word_re.findall((text or "").lower())
    return [w for w in words if w not in _STOPWORDS and len(w) > 2]


def signature(title, summary):
    """Weighted bag-of-words signature: title tokens weighted TITLE_WEIGHT
    times heavier than summary tokens, so headline overlap - the most
    reliable same-story signal - dominates the similarity score. Returned as
    a Counter."""
    bag = Counter()
    for tok in _tokenize(title):
        bag[tok] += TITLE_WEIGHT
    for tok in _tokenize(summary)[:SUMMARY_TOKEN_CAP]:
        bag[tok] += 1
    return bag


def jaccard(bag_a, bag_b):
    """Ruzicka similarity (weighted/multiset Jaccard): sum of per-token
    minimums over sum of per-token maximums. Reduces to ordinary Jaccard
    when every weight is 1."""
    tokens = set(bag_a) | set(bag_b)
    if not tokens:
        return 0.0
    num = sum(min(bag_a.get(t, 0), bag_b.get(t, 0)) for t in tokens)
    den = sum(max(bag_a.get(t, 0), bag_b.get(t, 0)) for t in tokens)
    return num / den if den else 0.0


def signature_to_str(bag):
    return "|".join(f"{tok}:{w}" for tok, w in sorted(bag.items()))


def signature_from_str(s):
    bag = Counter()
    if not s:
        return bag
    for part in s.split("|"):
        tok, _, w = part.rpartition(":")
        bag[tok] = int(w)
    return bag


# Kept for backward compatibility / potential future use with much longer
# documents, where SimHash's bit-voting does converge well.
def simhash(title, summary, bits=64):
    tokens = _tokenize(title) * 3 + _tokenize(summary)
    if not tokens:
        return 0
    v = [0] * bits
    for tok in tokens:
        h = int(hashlib.md5(tok.encode("utf-8")).hexdigest(), 16)
        for i in range(bits):
            v[i] += 1 if (h >> i) & 1 else -1
    fingerprint = 0
    for i in range(bits):
        if v[i] > 0:
            fingerprint |= (1 << i)
    return fingerprint


def hamming_distance(a, b):
    return bin(a ^ b).count("1")


def cluster_new_articles(db, config):
    """Fetch un-clustered articles, compute their token-set signature, and
    group each with the best-matching recent article whose Jaccard
    similarity clears the configured threshold. Mutates the DB: sets
    dedup_sig, cluster_id, is_primary for every newly-clustered article.

    Scope-aware primary promotion: a cluster's "primary" article is the one
    that gets filtered and classified (see briefing.py) - the rest just ride
    along for the "covered by N outlets" note. If a cluster contains both a
    local-scope and an international-scope article (e.g. a Pakistan story
    covered by both Dawn and BBC), the local one is promoted to primary.
    Local coverage of a story is the stronger signal that it matters to a
    Pakistan-focused reader, and it means the article gets checked against
    the (usually more permissive) local ruleset rather than potentially
    being dropped by the international scope's region filter.

    Returns the number of articles processed.
    """
    dedup_cfg = config["dedup"]
    threshold = dedup_cfg.get("jaccard_threshold", 0.30)
    window_hours = dedup_cfg["cluster_window_hours"]

    import time
    now = int(time.time())
    since = now - window_hours * 3600

    # All recent articles (including already-clustered ones) form the
    # comparison pool; only articles with cluster_id IS NULL get *assigned*.
    recent = db.recent_articles(since_ts=since, unclustered_only=False)
    unclustered = [a for a in recent if a["cluster_id"] is None]

    # Build signatures for anything missing one.
    for a in recent:
        if not a.get("dedup_sig"):
            a["dedup_sig"] = signature_to_str(signature(a["title"], a["summary_raw"]))

    # Cache parsed sets so we're not re-splitting strings in the inner loop.
    sig_cache = {a["id"]: signature_from_str(a["dedup_sig"]) for a in recent}

    processed = 0
    for article in unclustered:
        sig = sig_cache[article["id"]]
        best_match = None
        best_score = threshold
        for other in recent:
            if other["id"] == article["id"] or other["cluster_id"] is None:
                continue
            score = jaccard(sig, sig_cache[other["id"]])
            if score >= threshold and score > best_score:
                best_score = score
                best_match = other

        if best_match:
            cluster_id = best_match["cluster_id"]
            is_primary = False  # joining an existing cluster, not the representative
        else:
            cluster_id = db.next_cluster_id()
            is_primary = True

        db.set_cluster(article["id"], article["dedup_sig"], cluster_id, is_primary)
        article["cluster_id"] = cluster_id  # so later articles in this same
        article["is_primary"] = is_primary  # batch can match against it too
        processed += 1

        # Scope-aware primary promotion: if the article joining this cluster
        # is local-scope and the current primary isn't, swap them.
        if not is_primary and article.get("scope") == "local":
            current_primary = db.get_primary_of_cluster(cluster_id)
            if current_primary and current_primary.get("scope") != "local":
                db.set_primary(current_primary["id"], False)
                db.set_primary(article["id"], True)
                current_primary["is_primary"] = False
                article["is_primary"] = True

    return processed
