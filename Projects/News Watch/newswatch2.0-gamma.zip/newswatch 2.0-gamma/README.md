# NewsWatch

A local, private news-briefing tool. It scrapes RSS feeds, filters by region
and topic using your local LLM (llama3.1:8b via Ollama), tracks specific
topics (wars, protests, marches...) with automatic expiry, and produces a
formatted PDF brief divided by topic. Nothing leaves your machine except the
RSS fetches themselves.

## How it works (the two things you asked about most)

**Avoiding duplicates, at two layers:**
1. *Exact*: every article's URL is cleaned of tracking junk (`?utm_source=...`
   etc.) and hashed. The database rejects re-inserting the same URL - this
   alone kills most "duplicate" noise from re-running the scraper.
2. *Near*: the same real story reported by five outlets with five different
   URLs and slightly different headlines gets caught by comparing the
   overlap of significant words between articles published close together
   in time (a similarity score, not exact matching). Only one article per
   cluster - the "primary" - ever appears in a brief; the rest are kept in
   the database so you still see "covered by 4 outlets" as a signal of how
   big a story is.

**Filtering for relevance, in two stages, to keep the LLM fast:**
1. *Cheap keyword pass* (instant, no LLM): drops anything matching your
   exclusion list, and drops anything outside your region list - unless it
   matches a watchlist topic, since a war or protest you're explicitly
   tracking shouldn't get dropped just because an article didn't happen to
   name your region.
2. *LLM pass* (only for what survives step 1): llama3.1:8b judges real
   newsworthiness, tags topics, checks for watchlist matches, and writes a
   one-line neutral summary - in batches, so an 8B model on modest hardware
   isn't stuck classifying hundreds of obviously-irrelevant articles.

## Setup

1. Install [Ollama](https://ollama.com) and pull the model:
   ```bash
   ollama pull llama3.1:8b
   ollama serve   # if it isn't already running as a service
   ```
2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt --break-system-packages
   ```
3. Open `config.yaml` and edit:
   - `sources`: add/remove RSS feeds
   - `regions.include`: keywords for the region(s) you care about (leave
     empty to accept all regions)
   - `exclusions.keywords`: things you never want to see
   - `llm.model`: change if you're using a different local model name

## Day-to-day use

**Interactive shell (recommended)** - pretty output, and typing `/` shows
command suggestions that narrow down as you keep typing:
```bash
python main.py shell
```
```
newswatch> /
run  watchlist  sources  status  help  exit  quit
newswatch> /watch          <- suggestions narrow as you type
watchlist
newswatch> /watchlist a
add
newswatch> /watchlist add
New watchlist topic (Ctrl+C to cancel any time)
  Topic name (e.g. 'Sudan civil war'): Sudan civil war
  Keywords, comma-separated (e.g. Sudan,RSF,Khartoum): Sudan,RSF,Khartoum
  Category [war, protest, march, election, disaster, other]: war
  Track for how many days? [14]: 21
  Priority 1 (normal) - 3 (urgent) [1]: 3
Added #1: Sudan civil war ...
```
Available commands: `/run`, `/watchlist add|list|remove|renew`,
`/sources list`, `/status`, `/help`, `/exit`.

**Plain CLI** (scriptable, good for cron - see below):
```bash
python main.py run
```
This scrapes all sources, dedupes, filters, classifies, and writes a PDF to
`./briefs/brief_YYYY-MM-DD.pdf`. Run it as often as you like (e.g. once a
day via cron) - articles already included in a brief won't be repeated in
future briefs.

Manage the watchlist (topics that get their own highlighted section and
bypass the region filter, e.g. an ongoing war or a protest movement):
```bash
# Add a topic, tracked for 21 days, high priority
python main.py watchlist add "Sudan civil war" --keywords Sudan,RSF,Khartoum,SAF --category war --ttl 21 --priority 3

# See what's currently active and how long each has left
python main.py watchlist list

# Extend a topic that's still relevant
python main.py watchlist renew 1 --ttl 14

# Drop a topic early
python main.py watchlist remove 1
```
Topics expire automatically once their TTL passes - that's what keeps the
watchlist (and the LLM's per-cycle workload) from growing without bound.

### Automating it (optional)

Add a daily cron entry so the brief is waiting for you each morning:
```bash
# 7am every day
0 7 * * * cd /path/to/newswatch && python3 main.py run >> run.log 2>&1
```

## Files

| File | Purpose |
|---|---|
| `config.yaml` | Everything you're likely to want to tune |
| `main.py` | CLI - `run`, `watchlist`, and `markets-check` commands |
| `scraper.py` | RSS fetching |
| `dedup.py` | Exact + near-duplicate detection |
| `filters.py` | Stage-1 cheap keyword filter |
| `llm.py` | Stage-2 Ollama classification + section summaries |
| `interactive.py` | Pretty shell with `/` command autocomplete (rich + prompt_toolkit) |
| `watchlist.py` | Add/list/remove/expire tracked topics |
| `markets.py` | KSE-100/crude/fuel readings - own cron, own DB table, no LLM |
| `briefing.py` | Orchestrates one full news run |
| `pdf_report.py` | Builds the formatted PDF (news + Markets table) |
| `db.py` | SQLite schema + queries |
| `newswatch.db` | Created on first run - your article + market history |
| `briefs/` | Generated PDFs land here |

## Local vs. international news

Every source in `config.yaml` is tagged with a `scope: local` or `scope:
international`. This isn't about the outlet's home country — it's about the
feed's content focus. For example, `Geo News - InterNational` is published
by a Pakistani outlet, but that specific feed is its international desk, so
it's tagged `international`.

Each scope gets its own filtering rules under `scopes:` in the config —
local sources are already Pakistan-focused, so they typically don't need a
region filter (just exclusions); international sources cover the whole
world, so a region filter keeps only the international stories that
actually matter to you. The watchlist stays shared across both scopes,
since a war or protest you're tracking matters regardless of which desk
covered it.

If the same real-world story is picked up by both a local and an
international source (e.g. Dawn and BBC both covering a Pakistan story),
the local article is automatically promoted to represent that story in the
brief - local coverage is treated as the stronger relevance signal, and it
means the story gets checked against the (usually more permissive) local
ruleset instead of potentially being dropped by the international scope's
region filter.

The PDF brief reflects this with two clearly divided sections - Local News
and International News - each internally organized by topic, sitting below
the shared Watchlist section.

## Markets (KSE-100, crude, fuel prices)

Completely separate system from the news pipeline above - no dedup, no
filtering, no LLM involved. It just fetches, diffs against the last stored
reading, and stores the new one:

```bash
python main.py markets-check
```

Configured under `markets:` in `config.yaml`:
- `kse100` - the KSE-100 index level, via the [`psxdata`](https://pypi.org/project/psxdata/) package
- `crude_wti` / `crude_brent` - via Yahoo Finance (`yfinance`)
- `fuel_petrol` / `fuel_diesel` - scraped from an OGRA/PSO pricing page and
  regex-matched out of the page text

**Run `markets-check` once and check the printed values before trusting
it**, especially the fuel prices - OGRA/PSO pages don't have a stable
public API, their markup changes without notice, and the regex patterns in
`config.yaml` (`markets.fuel_source.patterns`) were written without being
able to verify them against the live page. If a pattern stops matching,
`markets-check` logs a warning for that one ticker and skips it - it won't
silently store a wrong number, and every other ticker still runs.

Run it on its own schedule, independent of the daily `run`:
```bash
# every few hours, e.g. matching markets.update_times in config.yaml
0 10,13,16 * * * cd /path/to/newswatch && python3 main.py markets-check >> markets.log 2>&1
```

The daily brief's PDF automatically picks up whatever the *latest* stored
reading is for each ticker when it builds - collection cadence
(`markets-check`, frequent) and report cadence (the brief, once daily) are
deliberately decoupled. If you've never run `markets-check`, the PDF's
Markets section just doesn't appear (no blank space, no error).

## Tuning dedup / filtering

- `freshness.max_age_hours` (default 48): articles whose *published* date is
  older than this get dropped, no matter how recently they were scraped.
  This matters because some feeds (especially smaller regional sites'
  `/feed/latest`-style endpoints) periodically serve archived/backlog items
  alongside new ones - freshly *scraped* isn't the same as freshly
  *published*. If you notice old news creeping into a brief, check
  `/status` or the run output's "dropped: N stale" count first; raise this
  value only if you deliberately want a longer lookback (e.g. weekly digest
  instead of daily).
- `dedup.jaccard_threshold` (default 0.35): raise it if unrelated stories
  are getting merged into one cluster; lower it if you spot obvious
  duplicates that aren't being caught.
- `dedup.cluster_window_hours` (default 72): how far back to compare new
  articles against for near-duplicate detection. A slow-developing story
  (e.g. a multi-day disaster) may warrant a longer window.
- `llm.batch_size` (default 8): lower it if your machine is slow and
  batches are timing out; raise it if classification is fast and you want
  fewer round-trips.

## Extending it

Ideas that fit naturally into this structure if you want to grow it later:
- A small Streamlit/Flask dashboard reading directly from `newswatch.db`
  for a browsable history instead of only PDFs.
- Auto-suggesting new watchlist topics when the same cluster keeps
  recurring across several days (the `briefs`/`brief_items` tables already
  give you the history to detect that).
- Emailing the PDF automatically after `run` completes.
