"""
briefing.py - orchestrates one full cycle:

  1. expire stale watchlist topics
  2. scrape RSS -> insert new articles (exact-dup rejected at DB level,
     each tagged with its source's scope: local or international)
  3. cluster near-duplicates via token-set similarity (scope-aware primary
     promotion: local coverage of a cluster wins representative status)
  4. stage 1 filter (per-scope region + exclusions, cheap)
  5. stage 2 filter (LLM relevance + topic tagging + watchlist matching)
  6. select "primary" article per cluster that passed both stages
  7. group into watchlist sections (scope-agnostic) + local/international
     topic sections
  8. render PDF, mark articles as briefed so they don't repeat tomorrow
"""

import os
import time
import json
from collections import defaultdict
from datetime import datetime

import scraper
import dedup
import filters
import watchlist as wl
from llm import OllamaClient
from pdf_report import build_pdf


def _cluster_sizes(db, article_ids_by_cluster):
    return {cid: db.cluster_size(cid) for cid in article_ids_by_cluster}


def run_cycle(db, config, verbose=True):
    brief_date = datetime.now().strftime("%Y-%m-%d")

    # 1. Expire stale watchlist topics first, so they don't influence this cycle.
    wl.expire_stale(db, verbose=verbose)
    active_watchlist = wl.list_active(db)

    # 2. Scrape.
    if verbose:
        print("Scraping RSS sources...")
    fetched, inserted = scraper.scrape_all(db, config, verbose=verbose)
    if verbose:
        print(f"  -> {fetched} items seen, {inserted} genuinely new (exact-dup filtered at DB level)")

    # 3. Near-duplicate clustering (rolling window).
    processed = dedup.cluster_new_articles(db, config)
    if verbose:
        print(f"  -> {processed} new articles clustered for near-duplicate detection")

    # Work over everything in the clustering window, not just today's insert,
    # so stories still developing get re-evaluated.
    window_hours = config["dedup"]["cluster_window_hours"]
    since_ts = int(time.time()) - window_hours * 3600
    candidates = db.recent_articles(since_ts=since_ts)

    # 4. Stage 1 filter (only articles that haven't been stage1-checked, i.e.
    #    passed_stage1 == 0 and passed_stage2 == 0, and are cluster primaries -
    #    no point filtering an article whose cluster is represented elsewhere).
    watchlist_keywords = filters.flat_watchlist_keywords(active_watchlist)
    stage1_pass = []
    reason_counts = defaultdict(int)
    for art in candidates:
        if not art["is_primary"]:
            continue
        if art["passed_stage2"]:
            continue  # already classified in a previous cycle
        passed, reason = filters.stage1_filter(art, config, watchlist_keywords)
        db.mark_stage1(art["id"], passed)
        reason_counts[reason if not passed else "passed"] += 1
        if passed:
            stage1_pass.append(art)

    if verbose:
        total_primary = sum(1 for a in candidates if a["is_primary"])
        print(f"  -> stage 1 (keyword) filter: {len(stage1_pass)} / {total_primary} primary articles pass")
        dropped = {k: v for k, v in reason_counts.items() if k != "passed"}
        if dropped:
            breakdown = ", ".join(f"{v} {k}" for k, v in sorted(dropped.items(), key=lambda kv: -kv[1]))
            print(f"     dropped: {breakdown}")

    # 5. Stage 2 filter via LLM, batched.
    llm = OllamaClient(config)
    batch_size = config["llm"]["batch_size"]
    if verbose and stage1_pass:
        print(f"Classifying {len(stage1_pass)} articles with {config['llm']['model']} "
              f"({(len(stage1_pass) + batch_size - 1) // batch_size} batches)...")

    for i in range(0, len(stage1_pass), batch_size):
        batch = stage1_pass[i:i + batch_size]
        try:
            results = llm.classify_batch(batch, active_watchlist)
        except Exception as e:
            if verbose:
                print(f"  [!] LLM batch failed ({e}), skipping batch")
            continue
        for art in batch:
            r = results.get(art["id"])
            if not r:
                continue
            db.save_llm_result(
                art["id"], r["relevant"], r["relevance_score"], r["summary"],
                r["topics"], r["matched_watchlist_ids"],
            )
        if verbose:
            done = min(i + batch_size, len(stage1_pass))
            print(f"  -> {done}/{len(stage1_pass)}")

    # 6. Pull everything eligible for today's brief: passed both stages,
    #    is a cluster primary, and hasn't already appeared in a brief.
    all_eligible = db.candidates_for_brief(since_ts=since_ts)
    to_brief = [a for a in all_eligible if brief_date not in json.loads(a["briefed_on"] or "[]")]

    if verbose:
        print(f"  -> {len(all_eligible)} relevant articles total, {len(to_brief)} new for today's brief")

    # 7. Group into sections. Watchlist stays scope-agnostic (a war or
    #    protest you're tracking matters regardless of which desk covered
    #    it); everything else splits into local vs international topic
    #    sections using each article's own (possibly promoted) scope.
    watchlist_by_id = {w["id"]: w for w in active_watchlist}
    watchlist_articles = defaultdict(list)
    topic_articles_by_scope = {"local": defaultdict(list), "international": defaultdict(list)}

    for art in to_brief:
        matched = json.loads(art["matched_watchlist_ids"] or "[]")
        placed = False
        for wid in matched:
            if wid in watchlist_by_id:
                watchlist_articles[wid].append(art)
                placed = True
        if not placed:
            topics = json.loads(art["topics"] or "[]") or ["general"]
            scope = art.get("scope") or "international"
            topic_articles_by_scope.setdefault(scope, defaultdict(list))
            topic_articles_by_scope[scope][topics[0]].append(art)

    cluster_ids = {a["cluster_id"] for a in to_brief}
    sizes = {cid: db.cluster_size(cid) for cid in cluster_ids}

    watchlist_sections = []
    for w in sorted(active_watchlist, key=lambda x: -x["priority"]):
        arts = watchlist_articles.get(w["id"], [])
        intro = llm.summarize_section(w["topic"], arts) if arts else ""
        watchlist_sections.append({
            "topic": w["topic"], "category": w["category"],
            "ttl_str": wl.format_ttl(w["expires_at"]),
            "articles": arts, "intro": intro,
        })

    def build_topic_sections(topic_articles):
        sections = []
        for topic, arts in sorted(topic_articles.items(), key=lambda kv: -len(kv[1])):
            intro = llm.summarize_section(topic, arts)
            sections.append({"topic": topic, "articles": arts, "intro": intro})
        return sections

    local_sections = build_topic_sections(topic_articles_by_scope.get("local", {}))
    international_sections = build_topic_sections(topic_articles_by_scope.get("international", {}))

    # 8. Render PDF. Markets is entirely optional here - it just reads
    #    whatever markets.py (run on its own separate cron schedule) last
    #    wrote to the DB. If markets-check has never been run, this is an
    #    empty list and pdf_report.build_pdf skips the section entirely.
    market_readings = db.latest_market_readings()

    os.makedirs(config["output"]["pdf_dir"], exist_ok=True)
    pdf_path = os.path.join(config["output"]["pdf_dir"], f"brief_{brief_date}.pdf")
    build_pdf(
        pdf_path, brief_date, watchlist_sections, local_sections, international_sections, sizes,
        total_considered=len(candidates), total_included=len(to_brief),
        market_readings=market_readings,
    )

    brief_id = db.create_brief(brief_date, pdf_path, len(to_brief))
    for art in to_brief:
        db.mark_briefed(art["id"], brief_date)
        section = next((w["topic"] for w in active_watchlist
                         if w["id"] in json.loads(art["matched_watchlist_ids"] or "[]")), None) \
            or (json.loads(art["topics"] or "[]") or ["general"])[0]
        db.add_brief_item(brief_id, art["id"], section)

    if verbose:
        print(f"\nBrief written: {pdf_path}  ({len(to_brief)} articles)")

    return pdf_path
