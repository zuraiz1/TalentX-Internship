"""
watchlist.py - the "topics to keep an eye on" table, with TTL-based expiry.

Every topic (e.g. "Sudan civil war", "Punjab farmer protests") has:
    - keywords: what to match articles against
    - category: war / protest / march / election / disaster / other
    - expires_at: when it auto-deactivates
    - priority: 1-3, controls ordering in the PDF and can be used to bias
      relevance scoring later if you want

Expiry is enforced by expire_watchlist(), called at the start of every run
(see main.py). This is the mechanism that stops the watchlist from growing
forever and dragging down every future LLM batch - a topic you added to
track a protest three months ago should not still be silently costing you
tokens and cluttering every brief today.
"""

import time


def add(db, topic, keywords, category="other", ttl_days=None, priority=1, config=None):
    if ttl_days is None:
        ttl_days = config["watchlist"]["default_ttl_days"] if config else 14
    return db.add_watchlist(topic, keywords, category, ttl_days, priority)


def list_active(db):
    return db.list_watchlist(active_only=True)


def remove(db, watchlist_id):
    db.remove_watchlist(watchlist_id)


def renew(db, watchlist_id, ttl_days):
    db.renew_watchlist(watchlist_id, ttl_days)


def expire_stale(db, verbose=True):
    expired = db.expire_watchlist()
    if verbose and expired:
        for row in expired:
            print(f"  [watchlist] expired: '{row['topic']}' (id={row['id']})")
    return expired


def format_ttl(expires_at):
    remaining = expires_at - int(time.time())
    if remaining <= 0:
        return "expired"
    days = remaining // 86400
    hours = (remaining % 86400) // 3600
    if days > 0:
        return f"{days}d {hours}h left"
    return f"{hours}h left"
