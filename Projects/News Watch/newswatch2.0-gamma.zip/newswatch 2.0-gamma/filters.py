"""
filters.py - stage 1 filtering: fast, free, no LLM involved.

This is what keeps the local LLM's workload small. A typical multi-source
RSS pull can have hundreds of items; running all of them through llama3.1:8b
is slow and pointless when most are obviously out of scope (sports scores,
celebrity gossip, wrong region). Stage 1 prunes with plain keyword matching,
and only the survivors go to the LLM in llm.py for real judgement.

Three independent checks, in order (cheapest / most decisive first):
    - freshness: if the article's *published* date (not scrape time) is
      older than `freshness.max_age_hours` -> reject. Shared across scopes -
      this is what stops feeds that serve archive/backlog items from
      contaminating a "daily" brief with old news that merely happened to
      be freshly scraped.
    - exclusion:      if ANY exclusion keyword matches -> reject outright.
    - region inclusion: if `regions.include` is non-empty, article must match
      at least ONE region keyword, UNLESS it matches an active watchlist
      keyword and `watchlist_bypasses_region_filter` is true (wars/protests
      you're explicitly tracking shouldn't get dropped just because the
      article didn't happen to mention your region of interest by name).

Exclusion and region rules are looked up per SCOPE (config["scopes"][scope]),
since local and international sources warrant different bars - see
config.yaml for the reasoning. Freshness is global across both scopes.
"""

import re
import time


def _make_matcher(keywords):
    if not keywords:
        return None
    pattern = "|".join(re.escape(k) for k in keywords)
    return re.compile(r"\b(" + pattern + r")\b", re.IGNORECASE)


def stage1_filter(article, config, watchlist_keywords, scope=None):
    """Returns (passed: bool, reason: str). `scope` defaults to the
    article's own stored scope if not passed explicitly."""
    max_age_hours = config.get("freshness", {}).get("max_age_hours")
    published_at = article.get("published_at")
    if max_age_hours and published_at:
        age_hours = (time.time() - published_at) / 3600
        if age_hours > max_age_hours:
            return False, "stale"

    scope = scope or article.get("scope") or "international"
    scope_cfg = config.get("scopes", {}).get(scope)
    if scope_cfg is None:
        return False, f"unknown_scope:{scope}"

    text = f"{article['title']} {article.get('summary_raw') or ''}"

    excl_matcher = _make_matcher(scope_cfg["exclusions"]["keywords"])
    if excl_matcher and excl_matcher.search(text):
        return False, "excluded_keyword"

    include_kws = scope_cfg["regions"]["include"]
    if not include_kws:
        return True, "no_region_filter"

    region_matcher = _make_matcher(include_kws)
    if region_matcher and region_matcher.search(text):
        return True, "region_match"

    if scope_cfg["regions"].get("watchlist_bypasses_region_filter", True) and watchlist_keywords:
        wl_matcher = _make_matcher(watchlist_keywords)
        if wl_matcher and wl_matcher.search(text):
            return True, "watchlist_bypass"

    return False, "out_of_region"


def flat_watchlist_keywords(watchlist_rows):
    """Flatten every active watchlist topic's keywords into one list, for the
    stage-1 bypass check."""
    import json
    out = []
    for row in watchlist_rows:
        out.extend(json.loads(row["keywords"]))
    return out
