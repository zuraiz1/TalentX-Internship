"""
markets.py - fetches market/commodity readings on their own schedule,
completely decoupled from the RSS/LLM news pipeline.

No dedup, no filtering, no LLM cost: fetch -> diff against the last stored
reading for that key -> store. Meant to be run often and cheaply (cron
calling `python main.py markets-check`), independent of the once-daily
news brief - the brief just reads whatever's latest in the DB when it
builds (see pdf_report.build_markets_table / db.latest_market_readings).

Each ticker in config["markets"]["tickers"] has a "type" that selects a
fetcher:
    psx_index    - PSX index level, via the `psxdata` package
    yfinance     - any Yahoo Finance symbol, via the `yfinance` package
    fuel_scrape  - Pakistani petrol/diesel retail price, scraped from a
                   configurable page + regex (see NOTE below)

NOTE on fuel_scrape: OGRA/PSO pricing pages don't expose a stable public
API, their markup changes without notice, and this sandbox has no live
network access to verify a selector/regex against the current page.
config["markets"]["fuel_source"] in config.yaml is a starting point, not
a verified scraper - run `python main.py markets-check` once, check the
printed petrol/diesel values against what OGRA actually published, and
adjust the regex patterns in config.yaml if they don't match. A failed
fuel fetch raises MarketFetchError (caught and logged per-ticker below)
rather than silently storing a wrong number.
"""

import re
import time


class MarketFetchError(Exception):
    """Raised by a fetcher when it can't produce a reading. run_check()
    catches this per-ticker so one bad source doesn't kill the whole run."""


# ---------------- individual fetchers ----------------
# Each returns a bare float value. Unit/label/delta bookkeeping happens in
# fetch_reading()/run_check() so the fetchers stay simple and independently
# testable (that's also why run_check() takes a swappable fetch_fn -
# see smoke_test.py for stubbed versions of these).

def fetch_psx_index(symbol):
    try:
        import psxdata
    except ImportError:
        raise MarketFetchError("psxdata package not installed (pip install psxdata)")
    try:
        df = psxdata.indices(symbol)
    except Exception as e:
        raise MarketFetchError(f"psxdata.indices({symbol!r}) failed: {e}")
    if df is None or df.empty:
        raise MarketFetchError(f"psxdata returned no data for index {symbol!r}")
    # current_index is repeated on every constituent row - any row gives
    # the index level itself, cheaper columns aren't worth chasing here.
    try:
        return float(df.iloc[0]["current_index"])
    except (KeyError, ValueError, TypeError) as e:
        raise MarketFetchError(f"unexpected psxdata columns for {symbol!r}: {e}")


def fetch_yfinance(symbol):
    try:
        import yfinance as yf
    except ImportError:
        raise MarketFetchError("yfinance package not installed (pip install yfinance)")
    try:
        fast_info = yf.Ticker(symbol).fast_info
        price = fast_info["last_price"] if hasattr(fast_info, "__getitem__") else fast_info.last_price
    except Exception as e:
        raise MarketFetchError(f"yfinance lookup for {symbol!r} failed: {e}")
    if price is None:
        raise MarketFetchError(f"yfinance returned no price for {symbol!r}")
    return float(price)


def fetch_fuel(product, config):
    import requests
    fuel_cfg = (config.get("markets") or {}).get("fuel_source") or {}
    url = fuel_cfg.get("url")
    pattern = (fuel_cfg.get("patterns") or {}).get(product)
    if not url or not pattern:
        raise MarketFetchError(
            f"markets.fuel_source.url / patterns.{product} not set in config.yaml"
        )
    timeout = fuel_cfg.get("timeout_seconds", 15)
    try:
        resp = requests.get(
            url, timeout=timeout,
            headers={"User-Agent": "Mozilla/5.0 (compatible; NewsWatch markets module)"},
        )
        resp.raise_for_status()
    except Exception as e:
        raise MarketFetchError(f"fetching {url} failed: {e}")

    match = re.search(pattern, resp.text, re.IGNORECASE)
    if not match:
        raise MarketFetchError(
            f"couldn't find a {product} price on {url} with the configured pattern - "
            f"the page markup may have changed; check config.yaml markets.fuel_source.patterns.{product}"
        )
    try:
        return float(match.group(1).replace(",", ""))
    except (ValueError, IndexError) as e:
        raise MarketFetchError(f"matched pattern but couldn't parse a number ({e})")


# ---------------- dispatch + orchestration ----------------

def fetch_reading(key, ticker_cfg, config):
    """Dispatch one ticker to its fetcher. Returns (value, unit, label).
    Raises MarketFetchError on any failure - callers decide what to do."""
    ttype = ticker_cfg.get("type")
    label = ticker_cfg.get("label", key)
    unit = ticker_cfg.get("unit", "")

    if ttype == "psx_index":
        symbol = ticker_cfg.get("symbol")
        if not symbol:
            raise MarketFetchError(f"{key}: missing 'symbol' for psx_index")
        value = fetch_psx_index(symbol)
    elif ttype == "yfinance":
        symbol = ticker_cfg.get("symbol")
        if not symbol:
            raise MarketFetchError(f"{key}: missing 'symbol' for yfinance")
        value = fetch_yfinance(symbol)
    elif ttype == "fuel_scrape":
        product = ticker_cfg.get("product")
        if not product:
            raise MarketFetchError(f"{key}: missing 'product' for fuel_scrape")
        value = fetch_fuel(product, config)
    else:
        raise MarketFetchError(f"{key}: unknown ticker type {ttype!r}")

    return value, unit, label


def _format_delta(delta, delta_pct):
    if delta is None:
        return " (first reading, no prior value to compare)"
    sign = "+" if delta >= 0 else ""
    pct = f", {sign}{delta_pct:.1f}%" if delta_pct is not None else ""
    return f" ({sign}{delta:.2f}{pct})"


def run_check(db, config, verbose=True, fetch_fn=fetch_reading):
    """Fetch every configured ticker once, diff each against its last
    stored reading, and write the new reading. One ticker failing
    (network hiccup, changed page markup, missing package) never stops
    the others - each is caught and logged independently.

    fetch_fn is swappable so tests can stub out network calls; production
    code just uses the default (fetch_reading, which hits the real APIs).
    """
    tickers = (config.get("markets") or {}).get("tickers") or {}
    if not tickers:
        if verbose:
            print("No markets.tickers configured in config.yaml - nothing to check.")
        return []

    now = int(time.time())
    results = []
    for key, ticker_cfg in tickers.items():
        try:
            value, unit, label = fetch_fn(key, ticker_cfg, config)
        except MarketFetchError as e:
            if verbose:
                print(f"  [!] {key}: {e}")
            continue
        except Exception as e:  # belt-and-suspenders - a bad fetcher shouldn't kill the run
            if verbose:
                print(f"  [!] {key}: unexpected error: {e}")
            continue

        prev = db.latest_market_reading(key)
        delta = None
        delta_pct = None
        if prev is not None:
            delta = value - prev["value"]
            if prev["value"]:
                delta_pct = (delta / prev["value"]) * 100

        db.insert_market_reading(key, label, value, unit, delta, delta_pct, fetched_at=now)
        results.append({
            "key": key, "label": label, "value": value, "unit": unit,
            "delta": delta, "delta_pct": delta_pct, "fetched_at": now,
        })
        if verbose:
            print(f"  {label}: {value:.2f} {unit}{_format_delta(delta, delta_pct)}")

    return results
