"""
markets_smoke_test.py - exercises markets.py end-to-end (dispatch, delta
computation vs. prior reading, DB storage, PDF table rendering) with
stubbed fetchers, since this sandbox has no live network access to PSX,
Yahoo Finance, or OGRA. Run once to sanity-check the install; safe to
delete afterwards.
"""
import yaml

from db import DB
import markets
from pdf_report import build_pdf

config = yaml.safe_load(open("config.yaml"))
config["output"]["db_path"] = "./markets_smoke_test.db"

db = DB(config["output"]["db_path"])


# Stub fetch_fn: same signature as markets.fetch_reading, but returns
# canned values instead of hitting psxdata/yfinance/requests. Lets us
# test dispatch + delta math + storage without a network.
def stub_fetch(key, ticker_cfg, cfg, values):
    if key not in values:
        raise markets.MarketFetchError(f"stub has no value for {key!r}")
    return values[key], ticker_cfg.get("unit", ""), ticker_cfg.get("label", key)


# --- first run: no prior readings, so every delta should be None ---
round1 = {
    "kse100": 138421.55, "crude_wti": 71.32, "crude_brent": 75.10,
    "fuel_petrol": 272.11, "fuel_diesel": 278.44,
}
results1 = markets.run_check(db, config, verbose=True, fetch_fn=lambda k, t, c: stub_fetch(k, t, c, round1))
print(f"\nround 1: {len(results1)} readings recorded")
assert len(results1) == 5, "expected all 5 configured tickers to be fetched"
assert all(r["delta"] is None for r in results1), "first-ever reading should have no delta"

# --- second run: values moved, so deltas should now be non-null and correct ---
round2 = {
    "kse100": 139900.00, "crude_wti": 70.10, "crude_brent": 75.10,  # brent unchanged on purpose
    "fuel_petrol": 275.61, "fuel_diesel": 278.44,                    # diesel unchanged on purpose
}
results2 = markets.run_check(db, config, verbose=True, fetch_fn=lambda k, t, c: stub_fetch(k, t, c, round2))
print(f"\nround 2: {len(results2)} readings recorded")

by_key = {r["key"]: r for r in results2}
assert abs(by_key["kse100"]["delta"] - (139900.00 - 138421.55)) < 1e-6, "kse100 delta miscalculated"
assert by_key["kse100"]["delta"] > 0, "kse100 should show a positive delta"
assert by_key["crude_wti"]["delta"] < 0, "crude_wti should show a negative delta (price dropped)"
assert by_key["crude_brent"]["delta"] == 0, "unchanged brent should have a zero (not None) delta on 2nd reading"
print("delta math OK (up/down/unchanged all correct)")

# --- a ticker whose fetcher fails shouldn't take down the rest of the run ---
partial = dict(round2)
del partial["fuel_diesel"]  # simulate the fuel page's diesel pattern failing to match
results3 = markets.run_check(db, config, verbose=True, fetch_fn=lambda k, t, c: stub_fetch(k, t, c, partial))
assert len(results3) == 4, "one failed fetcher should not block the other four"
assert "fuel_diesel" not in {r["key"] for r in results3}
print("partial-failure isolation OK (4/5 tickers still recorded)")

# --- latest_market_readings() should return exactly one row per key (the newest) ---
latest = db.latest_market_readings()
assert len(latest) == 5, f"expected 5 distinct keys, got {len(latest)}"
latest_by_key = {r["key"]: r for r in latest}
assert latest_by_key["fuel_diesel"]["value"] == round2["fuel_diesel"], \
    "fuel_diesel should still show its round-2 value (round 3's fetch failed, so nothing new was written)"
assert latest_by_key["kse100"]["value"] == round2["kse100"]
print("latest_market_readings() OK (one row per key, most recent wins)")

# --- render a real PDF including the Markets table, to catch any rendering bugs ---
path = build_pdf(
    "./markets_smoke_test_brief.pdf", "2026-08-12",
    watchlist_sections=[], local_sections=[], international_sections=[],
    cluster_sizes={}, total_considered=0, total_included=0,
    market_readings=latest,
)
print(f"\nPDF (with Markets table) written to {path}")

# --- and confirm build_pdf still works with market_readings omitted (backward compat) ---
path2 = build_pdf(
    "./markets_smoke_test_brief_no_markets.pdf", "2026-08-12",
    watchlist_sections=[], local_sections=[], international_sections=[],
    cluster_sizes={}, total_considered=0, total_included=0,
)
print(f"PDF (no markets_readings arg, backward-compat check) written to {path2}")

db.close()
print("\nMARKETS SMOKE TEST PASSED")
