"""
smoke_test.py - exercises the whole pipeline (DB, dedup, stage1 filter,
mocked stage2 LLM, watchlist, PDF build) without needing live internet
access to RSS feeds or a running Ollama instance. Run once to sanity-check
the install; safe to delete afterwards.
"""
import time
import json
import yaml

from db import DB
import dedup
import filters
import watchlist as wl
from pdf_report import build_pdf

config = yaml.safe_load(open("config.yaml"))
config["output"]["db_path"] = "./smoke_test.db"

db = DB(config["output"]["db_path"])

# --- seed a watchlist topic ---
wid = wl.add(db, "Gaza conflict", ["Gaza", "Hamas", "Israel", "ceasefire"], "war", ttl_days=1, priority=3, config=config)
print("watchlist added:", wid)

# --- seed articles: two near-duplicate reports of the same story from
#     different outlets + tracking-param variants of the SAME url, plus one
#     off-topic sports story that should get excluded, plus one out-of-region
#     story with no watchlist relevance. Reuters/Al Jazeera are international
#     scope; Local Gazette is local scope, to exercise scope routing too. ---
now = int(time.time())
raw_articles = [
    ("Reuters", "https://reuters.com/world/gaza-ceasefire-talks-resume?utm_source=rss",
     "Gaza ceasefire talks resume in Cairo", "Negotiators returned to the table in Cairo for a new round of talks.", "international"),
    ("Al Jazeera", "https://aljazeera.com/news/2026/8/11/gaza-ceasefire-talks-cairo",
     "Ceasefire talks over Gaza resume in Cairo", "Mediators say a new round of ceasefire negotiations began Tuesday in Cairo.", "international"),
    ("Reuters", "https://reuters.com/world/gaza-ceasefire-talks-resume?utm_source=newsletter",  # same article, different tracking param
     "Gaza ceasefire talks resume in Cairo", "Negotiators returned to the table in Cairo for a new round of talks.", "international"),
    ("Sports Daily", "https://sportsdaily.com/transfer-rumour-striker-moves",
     "Star striker in transfer rumour saga", "The celebrity-studded transfer window continues.", "international"),
    ("Local Gazette", "https://localgazette.com/city-council-budget-vote",
     "City council approves annual budget", "The council voted on next year's municipal budget.", "local"),
]

inserted_ids = []
for source, url, title, summary, scope in raw_articles:
    aid = db.insert_article(dedup.url_hash(url), dedup.canonicalize_url(url), title, summary, source, now, scope=scope)
    print(f"insert {source} [{scope}]: {'OK id='+str(aid) if aid else 'REJECTED (exact dup)'}")
    if aid:
        inserted_ids.append(aid)

# --- dedup / clustering ---
n = dedup.cluster_new_articles(db, config)
print(f"clustered {n} articles")

recent = db.recent_articles(since_ts=now - 3600)
for a in recent:
    print(f"  id={a['id']} cluster={a['cluster_id']} primary={a['is_primary']} scope={a['scope']} title={a['title'][:40]!r}")

# --- stage 1 filter (scope-aware) ---
active_wl = wl.list_active(db)
wl_kw = filters.flat_watchlist_keywords(active_wl)
stage1_survivors = []
for a in recent:
    if not a["is_primary"]:
        continue
    passed, reason = filters.stage1_filter(a, config, wl_kw)
    db.mark_stage1(a["id"], passed)
    print(f"  stage1 id={a['id']} scope={a['scope']} passed={passed} reason={reason} title={a['title'][:40]!r}")
    if passed:
        stage1_survivors.append(a)

# --- mocked stage 2 (skip real Ollama call) ---
for a in stage1_survivors:
    is_gaza = "gaza" in a["title"].lower() or "ceasefire" in a["title"].lower()
    db.save_llm_result(
        a["id"], True, 0.9 if is_gaza else 0.6,
        "Mock summary: " + a["title"],
        ["conflict"] if is_gaza else ["general"],
        [wid] if is_gaza else [],
    )

candidates = db.candidates_for_brief(since_ts=now - 3600)
print(f"\n{len(candidates)} candidates eligible for brief:")
for c in candidates:
    print(f"  id={c['id']} scope={c['scope']} score={c['relevance_score']} topics={c['topics']} watchlist={c['matched_watchlist_ids']}")

# --- build a real PDF from this mocked data, exercising the local/international split ---
sizes = {a["cluster_id"]: db.cluster_size(a["cluster_id"]) for a in candidates}
watchlist_articles = [c for c in candidates if json.loads(c["matched_watchlist_ids"] or "[]")]
other_articles = [c for c in candidates if not json.loads(c["matched_watchlist_ids"] or "[]")]
local_articles = [c for c in other_articles if c["scope"] == "local"]
international_articles = [c for c in other_articles if c["scope"] == "international"]

watchlist_sections = [{
    "topic": "Gaza conflict", "category": "war", "ttl_str": "~1d left",
    "articles": watchlist_articles, "intro": "Mocked intro paragraph for test purposes.",
}]
local_sections = [{"topic": "general", "articles": local_articles, "intro": ""}] if local_articles else []
international_sections = [{"topic": "general", "articles": international_articles, "intro": ""}] if international_articles else []

path = build_pdf("./smoke_test_brief.pdf", "2026-08-11", watchlist_sections, local_sections, international_sections,
                  sizes, total_considered=len(recent), total_included=len(candidates))
print(f"\nPDF written to {path}")
print(f"local_sections articles: {sum(len(s['articles']) for s in local_sections)}")
print(f"international_sections articles: {sum(len(s['articles']) for s in international_sections)}")

db.close()
print("\nSMOKE TEST PASSED")
